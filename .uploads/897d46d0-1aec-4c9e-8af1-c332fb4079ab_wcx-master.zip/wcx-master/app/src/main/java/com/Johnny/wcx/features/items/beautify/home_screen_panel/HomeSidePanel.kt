package com.Johnny.wcx.features.items.beautify.home_screen_panel

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isNotEmpty
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tencent.mm.ui.LauncherUI
import com.tencent.mm.ui.base.CustomViewPager
import com.tencent.mm.ui.mogic.WxViewPager
import dev.ujhhgtg.reflekt.reflekt
import com.Johnny.wcx.features.api.ui.WeMainActivityBeautifyApi

import com.Johnny.wcx.features.core.SwitchFeature
import java.lang.reflect.Method
import com.Johnny.wcx.features.items.beautify.AddMainScreenFab
import com.Johnny.wcx.ui.utils.LifecycleOwnerProvider
import com.Johnny.wcx.ui.utils.dpToPx
import com.Johnny.wcx.ui.utils.findViewWhich
import com.Johnny.wcx.ui.utils.setLifecycleOwner
import com.Johnny.wcx.ui.utils.theme.InjectedUiTheme
import com.Johnny.wcx.utils.HookHandle
import com.Johnny.wcx.utils.WeLogger
import com.Johnny.wcx.utils.android.showToast
import com.Johnny.wcx.utils.hookAfterDirectly
import com.Johnny.wcx.utils.hookBeforeDirectly
import com.Johnny.wcx.utils.reflection.float
import com.Johnny.wcx.utils.reflection.int
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.lang.ref.WeakReference
import java.util.WeakHashMap
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt
import android.graphics.Color as AndroidColor

private data class HomeSidePanelVisualTransform(
    val easedProgress: Float,
    val scale: Float,
    val translationXPx: Float,
    val translationYPx: Float,
)

private fun homeSidePanelVisualTransform(
    progress: Float,
    density: Float,
): HomeSidePanelVisualTransform {
    val p = progress.coerceIn(0f, 1f)
    val eased = (1f - (1f - p).toDouble().pow(1.35).toFloat()).coerceIn(0f, 1f)
    return HomeSidePanelVisualTransform(
        easedProgress = eased,
        scale = 1f - 0.05f * eased,
        translationXPx = (7f * density).roundToInt().toFloat() * eased,
        translationYPx = (8f * density).roundToInt().toFloat() * eased,
    )
}

private fun homeSidePanelShouldReparentExternalChrome(
    progress: Float,
    isCurrentHost: Boolean,
    isInContentWrapper: Boolean,
    parentClassName: String,
): Boolean =
    progress > 0f &&
        isCurrentHost &&
        !isInContentWrapper &&
        parentClassName != "androidx.appcompat.widget.ActionBarOverlayLayout"

@Suppress("DEPRECATION")
object HomeSidePanel : SwitchFeature() {

    // 注意：钱包符号不依赖 DexKit 委托解析（本对象已并入「微信主页侧边栏」开关，
    // 不再单独注册，避免因无 Dex 缓存导致整个侧边栏被跳过启用），改为运行时反射查找。

    private const val TAG = "HomeSidePanel"
    private const val LAUNCHER_BOTTOM_TAB_VIEW_CLASS = "com.tencent.mm.ui.LauncherUIBottomTabView"
    private val sessions = WeakHashMap<WxViewPager, WeakReference<HomeSidePanelSession>>()
    private val pendingEdgeToEdgeAttachListeners =
        WeakHashMap<View, View.OnAttachStateChangeListener>()
    private val dispatchTouchEventMethod by lazy {
        CustomViewPager::class.java.getDeclaredMethod("dispatchTouchEvent", MotionEvent::class.java)
    }
    private val pendingHostCancel = ThreadLocal<PendingHostCancel?>()

    // 侧边栏实现方式：1=方式一（原版），2=方式二（WeKit 版）；与 HomeSidePanelFeature 同一 pref 互斥
    private val sidePanelMode by com.Johnny.wcx.preferences.WePrefs.prefOption("hsp_side_mode", 1)

    /** 由「微信主页侧边栏」在方式二时调用，挂载 WeKit 负一屏面板。 */
    internal fun installPanel() {
        if (sidePanelMode != 2) return
        // 8.0.76 等版本上钱包类可能不同：静默反射查找，失败仅跳过余额读取
        val wallet = resolveWalletSymbolsReflexively()
        if (wallet != null) {
            HomeSidePanelWalletBalanceSource.install {
                readHomeSidePanelWalletBalance(
                    walletCacheReadMethod = wallet.read,
                    walletPayPluginClass = wallet.payPlugin,
                )
            }
            wallet.write.hookAfter {
                HomeSidePanelWalletBalanceSource.onCacheWrite(args[0], args[1])
            }
        } else {
            WeLogger.w(TAG, "wallet symbols not found on this WeChat version, wallet balance row unavailable")
        }
        LauncherUI::class.reflekt().firstMethodOrNull {
            name = "enableEdge2Edge"
            parameters()
        }?.hookBefore {
            result = true
        }
        LauncherUI::class.hookAfterOnCreate {
            ensureLauncherEdgeToEdge(thisObject as Activity)
        }
        LauncherUI::class.reflekt().firstMethod {
            name = "moveTaskToBack"
            parameters(Boolean::class)
        }.hookBefore {
            val activity = thisObject as? Activity ?: return@hookBefore
            val session = sessions.values.mapNotNull { it.get() }.firstOrNull { it.ownsActivity(activity) }
                ?: return@hookBefore
            if (session.consumeMoveTaskToBack()) {
                result = true
            }
        }
        LauncherUI::class.reflekt().firstMethod {
            name = "onResume"
            parameters()
        }.hookAfter {
            val activity = thisObject as Activity
            sessions.values.mapNotNull { it.get() }.firstOrNull { it.ownsActivity(activity) }
                ?.onLauncherResumed()
        }
        LauncherUI::class.reflekt().firstMethod {
            name = "startChatting"
            parameters(String::class, Bundle::class, Boolean::class)
        }.hookAfter {
            val activity = thisObject as Activity
            sessions.values.mapNotNull { it.get() }
                .firstOrNull { it.ownsActivity(activity) }
                ?.onChatTransition()
        }
        LauncherUI::class.reflekt().firstMethod {
            name = "closeChatting"
            parameters(Boolean::class)
        }.hookAfter {
            val activity = thisObject as Activity
            sessions.values.mapNotNull { it.get() }
                .firstOrNull { it.ownsActivity(activity) }
                ?.onChatTransition()
        }
        LauncherUI::class.reflekt().firstMethod {
            name = "onDestroy"
            parameters()
        }.hookAfter {
            val activity = thisObject as Activity
            removePendingEdgeToEdgeAttachListener(activity)
            removeSessionsForActivity(activity)
        }
        dispatchTouchEventMethod.hookBefore {
            pendingHostCancel.remove()
            val pager = thisObject as? WxViewPager ?: return@hookBefore
            val session = sessions[pager]?.get() ?: return@hookBefore
            val event = args[0] as? MotionEvent ?: return@hookBefore
            when (session.onPagerTouch(event)) {
                PagerTouchResult.PASS -> Unit
                PagerTouchResult.CANCEL_HOST -> {
                    pendingHostCancel.set(PendingHostCancel(event, event.action))
                    event.action = MotionEvent.ACTION_CANCEL
                }

                PagerTouchResult.CONSUME -> result = true
            }
        }
        dispatchTouchEventMethod.hookAfter {
            val event = args[0] as? MotionEvent ?: return@hookAfter
            val pending = pendingHostCancel.get() ?: return@hookAfter
            if (pending.event !== event) return@hookAfter
            event.action = pending.originalAction
            result = true
            pendingHostCancel.remove()
        }
        WeMainActivityBeautifyApi.methodDoOnCreate.hookAfter {
            val activity = thisObject!!.reflekt()
                .firstField {
                    type = "com.tencent.mm.ui.MMFragmentActivity"
                }
                .get()!! as Activity
            ensureLauncherEdgeToEdge(activity)
            val viewPager = thisObject!!.reflekt()
                .firstField {
                    name = "mViewPager"
                }
                .get()!! as WxViewPager
            val tabsAdapter = thisObject!!.reflekt()
                .firstField {
                    name = "mTabsAdapter"
                }
                .get()!!
            val parent = viewPager.parent as? FrameLayout
            if (parent == null) {
                WeLogger.e(TAG, "MainTabUI mViewPager parent is not a FrameLayout")
                return@hookAfter
            }
            if (sessions[viewPager]?.get() != null) return@hookAfter

            val session = HomeSidePanelSession(activity, parent, viewPager, tabsAdapter).also { it.attach() }
            session.setSelectedTab(viewPager.currentItem)
            sessions[viewPager] = WeakReference(session)
        }
    }

    private data class WalletSymbols(
        val read: Method,
        val write: Method,
        val payPlugin: Class<*>,
    )

    /**
     * 静默反射查找微信钱包缓存符号。
     *
     * 缓存类的混淆名跨版本会变（8.0.65~8.0.71 是 m1，8.0.79/8.0.80 是 j1），
     * 所以不写死名字，改为按结构特征校验：同时具备
     *   i(2 参) -> Object   读缓存
     *   j(2 参) -> void     写缓存（回调里能拿到余额）
     * 再加「支付插件类里有方法返回该缓存类」做交叉确认。
     * 找不到就返回 null，仅跳过余额行，不影响侧边栏其它功能。
     */
    private fun resolveWalletSymbolsReflexively(): WalletSymbols? = runCatching {
        val cacheCandidates = arrayOf(
            "com.tencent.mm.wallet_core.model.j1",
            "com.tencent.mm.wallet_core.model.m1",
        )
        var cacheClass: Class<*>? = null
        var readMethod: java.lang.reflect.Method? = null
        var writeMethod: java.lang.reflect.Method? = null
        for (name in cacheCandidates) {
            val c = runCatching { Class.forName(name) }.getOrNull() ?: continue
            val r = c.declaredMethods.firstOrNull {
                it.name == "i" && it.parameterCount == 2 && it.returnType == Any::class.java
            }
            val w = c.declaredMethods.firstOrNull {
                it.name == "j" && it.parameterCount == 2 && it.returnType == Void.TYPE
            }
            if (r != null && w != null) {
                cacheClass = c
                readMethod = r
                writeMethod = w
                break
            }
        }
        val cache = cacheClass
        val read = readMethod
        val write = writeMethod
        if (cache == null || read == null || write == null) {
            WeLogger.w(TAG, "wallet cache class not found in candidates")
            return@runCatching null
        }

        val pay = runCatching { Class.forName("com.tencent.mm.plugin.wxpay.g") }.getOrNull()
        if (pay == null || pay.declaredMethods.none { it.returnType == cache }) {
            WeLogger.w(TAG, "wallet pay plugin class not resolved")
            return@runCatching null
        }
        WeLogger.i(TAG, "wallet symbols resolved: cache=" + cache.name + ", pay=" + pay.name)
        WalletSymbols(read, write, pay)
    }.getOrElse {
        WeLogger.w(TAG, "resolveWalletSymbolsReflexively failed: " + (it.message ?: ""))
        null
    }

    internal fun uninstallPanel() {
        sessions.values.mapNotNull { it.get() }.forEach { it.detach() }
        sessions.clear()
        HomeSidePanelWalletBalanceSource.clear()
    }

    private fun removeSessionsForActivity(activity: Activity) {
        val iterator = sessions.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            val session = entry.value.get()
            if (session == null || session.ownsActivity(activity)) {
                session?.detach()
                iterator.remove()
            }
        }
    }

    private fun ensureLauncherEdgeToEdge(activity: Activity) {
        val window = activity.window
        val decor = window.decorView
        if (decor.isAttachedToWindow) {
            applyLauncherEdgeToEdge(window)
            return
        }
        if (pendingEdgeToEdgeAttachListeners[decor] != null) return
        val listener = object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(view: View) {
                pendingEdgeToEdgeAttachListeners.remove(view)
                view.removeOnAttachStateChangeListener(this)
                view.post {
                    applyLauncherEdgeToEdge(activity.window)
                }
            }

            override fun onViewDetachedFromWindow(view: View) = Unit
        }
        pendingEdgeToEdgeAttachListeners[decor] = listener
        decor.addOnAttachStateChangeListener(listener)
    }

    private fun removePendingEdgeToEdgeAttachListener(activity: Activity) {
        val decor = activity.window.decorView
        val listener = pendingEdgeToEdgeAttachListeners.remove(decor) ?: return
        decor.removeOnAttachStateChangeListener(listener)
    }

    private fun applyLauncherEdgeToEdge(window: Window) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = AndroidColor.TRANSPARENT
        window.decorView.requestApplyInsets()
    }

    private data class PendingHostCancel(
        val event: MotionEvent,
        val originalAction: Int,
    )

    private data class ActionBarTransformSnapshot(
        val originalPivotX: Float,
        val originalPivotY: Float,
        val transformPivotX: Float,
        val transformPivotY: Float,
        val scaleX: Float,
        val scaleY: Float,
        val translationX: Float,
        val translationY: Float,
    )

    private data class ToolbarProfileBinding(
        val host: RelativeLayout,
        val nativeTitle: TextView,
        val composeView: ComposeView,
    )

    private data class ObservedViewListeners(
        val attach: View.OnAttachStateChangeListener,
        val layout: View.OnLayoutChangeListener,
    )

    private enum class PagerTouchResult {
        PASS,
        CANCEL_HOST,
        CONSUME,
    }

    private class HomeSidePanelSession(
        private val activity: Activity,
        private val parent: FrameLayout,
        private val viewPager: WxViewPager,
        private val tabsAdapter: Any,
    ) {
        private val gestureConfig = homeSidePanelGestureConfig(
            density = activity.resources.displayMetrics.density,
        )
        private val gesture = HomeSidePanelGestureState(gestureConfig)
        private val decorRoot = activity.window.decorView as FrameLayout
        private val contentWrapper = FrameLayout(activity)
        private val overlayRoot = HomeSidePanelOverlayLayout(activity).also { it.session = this }
        private val dimView = View(activity)
        private val panelView = ComposeView(activity)
        private val panelBgView = ImageView(activity).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            alpha = 0f
        }
        private val stateScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        private val layoutStore = HomeSidePanelLayoutStore
        private val cityIndex = HomeSidePanelCityIndex(activity)
        private val weather = HomeSidePanelWeather(
            cityIndex = cityIndex,
            client = homeSidePanelHttpClient,
        )
        private val hitokoto = HomeSidePanelHitokoto(homeSidePanelHttpClient)
        private val runtimeStore = HomeSidePanelRuntimeStore(
            weather = weather,
            hitokoto = hitokoto,
            walletBalance = HomeSidePanelWalletBalanceSource,
            parentScope = stateScope,
            cacheStore = layoutStore,
        )
        private val panelState = HomeSidePanelState(
            activity = activity,
            profile = HomeSidePanelProfileLoader(
                cityIndex = cityIndex,
            ),
            weather = weather,
            hitokoto = hitokoto,
            runtimeStore = runtimeStore,
            location = HomeSidePanelLocation(cityIndex),
            scope = stateScope,
            layoutStore = layoutStore,
            closePanel = { afterClosed ->
                close(animated = true, oneShot = true, afterClosed = afterClosed)
            },
        )
        private val outlineProvider = ProgressOutlineProvider()

        private var animator: ValueAnimator? = null
        private var drawerWidthPx = 1
        private var renderedProgress = 0f
        private var dragging = false
        private var attached = false
        private var pendingSyncFlags = 0
        private var syncPosted = false
        private val parentLayoutListener = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            requestSync(SYNC_ALL)
        }
        private val decorLayoutListener = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            requestSync(SYNC_HIERARCHY or SYNC_GEOMETRY or SYNC_INSETS)
        }
        private val syncRunnable = Runnable {
            syncPosted = false
            if (!attached) {
                pendingSyncFlags = 0
                return@Runnable
            }
            runPendingSync()
        }
        private var parentClipChildren = true
        private var parentClipToPadding = true
        private val actionBarContainers = linkedSetOf<View>()
        private val actionBarTransformSnapshots = linkedMapOf<View, ActionBarTransformSnapshot>()
        private var fabHostView: View? = null
        private var fabOriginalParent: ViewGroup? = null
        private var fabOriginalLayoutParams: ViewGroup.LayoutParams? = null
        private var fabOriginalIndex = -1
        private var wasPanelVisible = false
        private var suppressCloseUntilNextFrame = false
        private var selectedTabIndex = HOME_TAB_INDEX
        private var chattingVisible = false
        private var cachedNativeBottomTabView: View? = null
        private var observedNativeBottomTabView: View? = null
        private var observedNativeBottomLinearLayout: LinearLayout? = null
        private var nativeBottomTabMissingLogged = false
        private var lastNativeContentInsetLogState: String? = null
        private val toolbarProfileBindings = linkedMapOf<RelativeLayout, ToolbarProfileBinding>()
        private val observedToolbarProfileHosts = linkedSetOf<RelativeLayout>()
        private val homeToolbarHosts = linkedSetOf<RelativeLayout>()
        private val chattingToolbarHosts = linkedSetOf<RelativeLayout>()
        private val nativeTitleVisibilities = linkedMapOf<TextView, Int>()
        private val tabsAdapterHookHandles = mutableListOf<Any>()
        private val observedViews = WeakHashMap<View, ObservedViewListeners>()
        private var pendingTransitionLayoutListener: View.OnLayoutChangeListener? = null

        fun attach() {
            if (attached) return
            attached = true

            parentClipChildren = parent.clipChildren
            parentClipToPadding = parent.clipToPadding
            parent.clipChildren = false
            parent.clipToPadding = false

            moveExistingChildrenIntoWrapper()
            contentWrapper.clipChildren = false
            contentWrapper.clipToPadding = false
            contentWrapper.outlineProvider = outlineProvider
            contentWrapper.clipToOutline = true

            dimView.setBackgroundColor(AndroidColor.BLACK)
            dimView.alpha = 0f
            dimView.isClickable = true
            dimView.setOnClickListener {
                if (renderedProgress > CLOSED_EPSILON) close(animated = true, oneShot = true)
            }

            panelView.setBackgroundColor(AndroidColor.TRANSPARENT)
            panelView.isClickable = true
            panelView.setLifecycleOwner(LifecycleOwnerProvider.getOrCreate(activity))
            panelView.setContent {
                InjectedUiTheme {
                    LaunchedEffect(panelState) {
                        val messagesJob = launch(start = CoroutineStart.UNDISPATCHED) {
                            panelState.messages.collect { message ->
                                showToast(activity, message)
                            }
                        }
                        panelState.start()
                        messagesJob.join()
                    }
                    val state by panelState.uiState.collectAsStateWithLifecycle()
                    HomeSidePanelContent(state, panelState)
                }
            }
            overlayRoot.clipChildren = false
            overlayRoot.clipToPadding = false
            overlayRoot.visibility = View.GONE
            overlayRoot.addView(
                dimView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                )
            )
            // 侧滑栏背景图：放在 panelView 下面，面板内容本身没有不透明底色，能透出来。
            overlayRoot.addView(
                panelBgView,
                FrameLayout.LayoutParams(
                    drawerWidthPx,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                )
            )
            overlayRoot.addView(
                panelView,
                FrameLayout.LayoutParams(
                    drawerWidthPx,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                )
            )
            applyPanelBackground()

            parent.addView(
                contentWrapper,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                )
            )
            decorRoot.addView(
                overlayRoot,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                )
            )
            parent.addOnLayoutChangeListener(parentLayoutListener)
            decorRoot.addOnLayoutChangeListener(decorLayoutListener)
            ViewCompat.setOnApplyWindowInsetsListener(contentWrapper) { _, insets ->
                requestSync(SYNC_INSETS)
                insets
            }
            stateScope.launch {
                panelState.uiState
                    .map { it.showToolbarProfile to it.hideWeChatTitle }
                    .distinctUntilChanged()
                    .collect { syncToolbarProfileVisibility() }
            }
            installTabsAdapterHooks()
            requestSync(SYNC_ALL)
        }

        private fun requestSync(flags: Int) {
            if (!attached) return
            pendingSyncFlags = pendingSyncFlags or flags
            if (syncPosted) return
            syncPosted = true
            parent.post(syncRunnable)
        }

        private fun runPendingSync() {
            val flags = pendingSyncFlags
            pendingSyncFlags = 0
            if (flags and SYNC_HIERARCHY != 0) {
                absorbStrayChildren()
                resolveExternalChrome()
                syncToolbarProfileBindings()
            }
            if (flags and SYNC_GEOMETRY != 0) {
                if (updateDrawerWidth()) {
                    applyProgress(renderedProgress)
                }
            }
            if (flags and SYNC_INSETS != 0) {
                syncNativeContentBottomInset()
            }
            if (flags and (SYNC_HIERARCHY or SYNC_GEOMETRY) != 0) {
                applyActionBarProgress(renderedProgress)
            }
        }

        private fun syncNativeContentBottomInset() {
            val bottomBar = cachedNativeBottomTabView
                ?.takeIf { it.isAttachedToWindow }
                ?: contentWrapper.findViewWhich<View> {
                    it.javaClass.name == LAUNCHER_BOTTOM_TAB_VIEW_CLASS
                }?.also { cachedNativeBottomTabView = it }
            val bottomLinearLayout = (bottomBar as? ViewGroup)?.directLinearLayout()
            if (observedNativeBottomTabView !== bottomBar) {
                observedNativeBottomTabView?.let(::unobserveView)
                observedNativeBottomTabView = bottomBar
            }
            if (observedNativeBottomLinearLayout !== bottomLinearLayout) {
                observedNativeBottomLinearLayout?.let(::unobserveView)
                observedNativeBottomLinearLayout = bottomLinearLayout
            }
            if (bottomBar == null) {
                if (!nativeBottomTabMissingLogged) {
                    WeLogger.w(TAG, "native bottom tab not found; launcher content inset pending")
                    nativeBottomTabMissingLogged = true
                }
                return
            }
            observeView(bottomBar, SYNC_INSETS)
            bottomLinearLayout?.let { observeView(it, SYNC_INSETS) }
            nativeBottomTabMissingLogged = false

            val replacementOwnsInsets =
                bottomBar.visibility != View.VISIBLE || bottomBar.findViewWhich<View> { it is ComposeView } != null
            val insets = ViewCompat.getRootWindowInsets(contentWrapper)
            val navigationBottom = insets
                ?.getInsets(WindowInsetsCompat.Type.navigationBars())
                ?.bottom
                ?: 0
            val tappableBottom = insets
                ?.getInsets(WindowInsetsCompat.Type.tappableElement())
                ?.bottom
                ?: 0
            val ancestorBottomInset = contentBottomGapToDecor()
            val nativeBottomInset = bottomBar.paddingBottom +
                (bottomLinearLayout?.paddingBottom ?: 0)
            val alreadyAvoidedBottom = ancestorBottomInset + nativeBottomInset
            val targetBottom = if (chattingVisible || replacementOwnsInsets) {
                0
            } else {
                (navigationBottom - alreadyAvoidedBottom).coerceAtLeast(0)
            }

            if (contentWrapper.paddingBottom != targetBottom) {
                contentWrapper.setPadding(
                    contentWrapper.paddingLeft,
                    contentWrapper.paddingTop,
                    contentWrapper.paddingRight,
                    targetBottom,
                )
            }
            val logState = "$targetBottom/$navigationBottom/$tappableBottom/$ancestorBottomInset/" +
                "$nativeBottomInset/$chattingVisible/$replacementOwnsInsets/${bottomBar.visibility}"
            if (lastNativeContentInsetLogState != logState) {
                WeLogger.d(
                    TAG,
                    "native content inset target=$targetBottom " +
                        "(navigation=$navigationBottom tappable=$tappableBottom " +
                        "ancestor=$ancestorBottomInset native=$nativeBottomInset " +
                        "chatting=$chattingVisible replacement=$replacementOwnsInsets " +
                        "wrapper=${contentWrapper.height}/${contentWrapper.paddingBottom} " +
                        "bottomBar=${bottomBar.height}/${bottomBar.top}/${bottomBar.bottom}/" +
                        "${bottomBar.paddingBottom}/${bottomBar.visibility} sysUi=0x" +
                        activity.window.decorView.systemUiVisibility.toString(16) + ")"
                )
                lastNativeContentInsetLogState = logState
            }
        }

        /**
         * contentWrapper 自己的 padding 不改变它的边界，因此这里得到的是微信祖先布局已经
         * 留出的底部空间。使用布局坐标而不是屏幕坐标，避免侧栏动画的 scale/translation
         * 被误算成系统栏补偿。
         */
        private fun contentBottomGapToDecor(): Int {
            var bottom = contentWrapper.bottom
            var ancestor = contentWrapper.parent as View
            while (ancestor !== decorRoot) {
                bottom += ancestor.top
                ancestor = ancestor.parent as View
            }
            return (decorRoot.height - bottom).coerceAtLeast(0)
        }

        /**
         * 8.0.65-8.0.69 把导航栏高度加在 LauncherUIBottomTabView 的直接 LinearLayout
         * 子项上；8.0.74+ 的新 Edge2EdgeHelper 则可能直接加在底栏本身。两者都要计入
         * 已有补偿，wrapper 只补剩余差值。
         */
        private fun ViewGroup.directLinearLayout(): LinearLayout? {
            for (index in 0 until childCount) {
                val child = getChildAt(index)
                if (child is LinearLayout) return child
            }
            return null
        }

        fun detach() {
            if (!attached) return
            attached = false
            parent.removeCallbacks(syncRunnable)
            parent.removeOnLayoutChangeListener(parentLayoutListener)
            decorRoot.removeOnLayoutChangeListener(decorLayoutListener)
            ViewCompat.setOnApplyWindowInsetsListener(contentWrapper, null)
            pendingTransitionLayoutListener?.let(parent::removeOnLayoutChangeListener)
            pendingTransitionLayoutListener = null
            observedViews.forEach { (view, listeners) ->
                view.removeOnAttachStateChangeListener(listeners.attach)
                view.removeOnLayoutChangeListener(listeners.layout)
            }
            observedViews.clear()
            observedToolbarProfileHosts.clear()
            animator?.cancel()
            animator = null
            tabsAdapterHookHandles.forEach { (it as? de.robv.android.xposed.XC_MethodHook.Unhook)?.unhook() }
            tabsAdapterHookHandles.clear()
            panelState.close()
            pendingSyncFlags = 0
            syncPosted = false
            clearToolbarProfileBindings()
            restoreActionBarTransform()
            restoreFabHostToOriginalParent()
            contentWrapper.setPadding(
                contentWrapper.paddingLeft,
                contentWrapper.paddingTop,
                contentWrapper.paddingRight,
                0,
            )
            cachedNativeBottomTabView = null
            observedNativeBottomTabView = null
            observedNativeBottomLinearLayout = null
            nativeBottomTabMissingLogged = false
            lastNativeContentInsetLogState = null
            restoreContent()
            panelView.disposeComposition()
            decorRoot.removeView(overlayRoot)
            contentWrapper.clipToOutline = false
            parent.removeView(contentWrapper)
            parent.clipChildren = parentClipChildren
            parent.clipToPadding = parentClipToPadding
        }

        fun setSelectedTab(index: Int) {
            val previousTabIndex = selectedTabIndex
            selectedTabIndex = index
            gesture.setSelectedTab(index)
            syncToolbarProfileVisibility()
            if (index != previousTabIndex) {
                requestSync(SYNC_HIERARCHY or SYNC_INSETS)
            }
            if (index == HOME_TAB_INDEX && previousTabIndex != HOME_TAB_INDEX) {
                panelState.onPanelOpened()
            }
            if (index != HOME_TAB_INDEX && renderedProgress > CLOSED_EPSILON) {
                close(animated = true)
            }
        }

        private fun installTabsAdapterHooks() {
            val reflectedTabsAdapter = tabsAdapter.reflekt()
            tabsAdapterHookHandles += reflectedTabsAdapter.firstMethod {
                name = "onPageSelected"
                parameters(int)
            }.hookBeforeDirectly {
                if (tabsAdapter !== thisObject) return@hookBeforeDirectly
                setSelectedTab(args[0] as Int)
            }
            tabsAdapterHookHandles += reflectedTabsAdapter.firstMethod {
                name = "onPageSelected"
                parameters(int)
            }.hookAfterDirectly {
                if (tabsAdapter !== thisObject) return@hookAfterDirectly
                val position = args[0] as Int
                if (position == HOME_TAB_INDEX) {
                    ensureLauncherEdgeToEdge(activity)
                }
            }
            tabsAdapterHookHandles += reflectedTabsAdapter.firstMethod {
                name = "onPageScrolled"
                parameters(int, float, int)
            }.hookBeforeDirectly {
                if (tabsAdapter !== thisObject) return@hookBeforeDirectly
                val position = args[0] as Int
                val offset = args[1] as Float
                if (position != HOME_TAB_INDEX || offset > PAGE_SETTLED_EPSILON) {
                    setSelectedTab(-1)
                } else {
                    setSelectedTab(viewPager.currentItem)
                }
            }
        }

        fun ownsActivity(candidate: Activity): Boolean = activity === candidate

        fun onLauncherResumed() {
            panelState.onLauncherResumed()
            requestSync(SYNC_ALL)
        }

        fun onChatTransition() {
            if (!attached) return
            requestSync(SYNC_HIERARCHY or SYNC_INSETS)
            pendingTransitionLayoutListener?.let(parent::removeOnLayoutChangeListener)
            val listener = object : View.OnLayoutChangeListener {
                override fun onLayoutChange(
                    view: View,
                    left: Int,
                    top: Int,
                    right: Int,
                    bottom: Int,
                    oldLeft: Int,
                    oldTop: Int,
                    oldRight: Int,
                    oldBottom: Int,
                ) {
                    parent.removeOnLayoutChangeListener(this)
                    if (pendingTransitionLayoutListener === this) {
                        pendingTransitionLayoutListener = null
                    }
                    requestSync(SYNC_ALL)
                }
            }
            pendingTransitionLayoutListener = listener
            parent.addOnLayoutChangeListener(listener)
        }

        fun open() {
            if (selectedTabIndex != HOME_TAB_INDEX || isChattingVisible()) return
            val from = renderedProgress
            animator?.cancel()
            animator = null
            dragging = false
            parent.requestDisallowInterceptTouchEvent(false)
            gesture.close()
            gesture.snapTo(from)
            animateTo(1f, from)
        }

        fun consumeMoveTaskToBack(): Boolean {
            if (suppressCloseUntilNextFrame) return true
            if (panelState.consumeSettingsBack()) {
                suppressCloseUntilNextFrame = true
                decorRoot.postOnAnimation {
                    suppressCloseUntilNextFrame = false
                }
                return true
            }
            if (renderedProgress <= 0f && !dragging && !gesture.isTracking) {
                return false
            }
            close(animated = true)
            return true
        }

        fun close(
            animated: Boolean,
            oneShot: Boolean = false,
            afterClosed: (() -> Unit)? = null,
        ) {
            if (suppressCloseUntilNextFrame) return
            val from = renderedProgress
            animator?.cancel()
            animator = null
            dragging = false
            parent.requestDisallowInterceptTouchEvent(false)
            gesture.close()
            if (animated) {
                animateTo(0f, from, oneShot, afterClosed)
            } else {
                applyProgress(0f)
                afterClosed?.invoke()
            }
        }

        fun onPagerTouch(event: MotionEvent): PagerTouchResult {
            return when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    beginGesture(event)
                    PagerTouchResult.PASS
                }

                MotionEvent.ACTION_MOVE -> {
                    when (gesture.onMove(event.x, event.y, event.eventTime)) {
                        HomeSidePanelGestureDecision.PASS,
                        HomeSidePanelGestureDecision.TRACKING,
                        -> PagerTouchResult.PASS

                        HomeSidePanelGestureDecision.CONSUME -> {
                            applyProgress(gesture.progress)
                            if (!dragging) {
                                dragging = true
                                parent.requestDisallowInterceptTouchEvent(true)
                                PagerTouchResult.CANCEL_HOST
                            } else {
                                PagerTouchResult.CONSUME
                            }
                        }
                    }
                }

                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        gesture.onCancel()
                        PagerTouchResult.PASS
                    } else {
                        val from = renderedProgress
                        val target = gesture.onUp(event.eventTime)
                        dragging = false
                        parent.requestDisallowInterceptTouchEvent(false)
                        animateTo(target, from, oneShot = target == 0f)
                        PagerTouchResult.CONSUME
                    }
                }

                MotionEvent.ACTION_CANCEL -> {
                    if (!dragging) {
                        gesture.onCancel()
                        PagerTouchResult.PASS
                    } else {
                        val from = renderedProgress
                        val target = gesture.onCancel()
                        dragging = false
                        parent.requestDisallowInterceptTouchEvent(false)
                        animateTo(target, from, oneShot = target == 0f)
                        PagerTouchResult.CONSUME
                    }
                }

                else -> if (dragging) PagerTouchResult.CONSUME else PagerTouchResult.PASS
            }
        }

        fun onOverlayInterceptTouch(event: MotionEvent): Boolean =
            handleIntercept(event, allowPanelPassthrough = true)

        fun onOverlayTouch(event: MotionEvent): Boolean =
            handleTouch(event)

        private fun handleIntercept(
            event: MotionEvent,
            allowPanelPassthrough: Boolean,
        ): Boolean {
            // 修复「侧边栏菜单点击无效」：面板内且接近完全展开时，把触摸事件整体放行给内容。
            // 原实现要求 renderedProgress >= 0.98f 且仅放行 DOWN/UP/CANCEL，导致手指轻微移动
            // 产生的 MOVE 会被拦截，子 View 随即收到 ACTION_CANCEL，clickable 不触发。
            // 现在：面板内只要未进入拖拽（!dragging）就一律放行，保证点击可靠；
            // 拖动关闭仍可通过面板外区域/关闭按钮完成。
            if (
                allowPanelPassthrough &&
                isInsidePanel(event.x) &&
                renderedProgress >= 0.90f &&
                !dragging
            ) {
                if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                    beginGesture(event)
                } else {
                    gesture.onCancel()
                }
                return false
            }

            return when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    beginGesture(event)
                    false
                }

                MotionEvent.ACTION_MOVE -> {
                    val decision = gesture.onMove(event.x, event.y, event.eventTime)
                    if (decision == HomeSidePanelGestureDecision.CONSUME) {
                        dragging = true
                        parent.requestDisallowInterceptTouchEvent(true)
                        applyProgress(gesture.progress)
                        true
                    } else {
                        false
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (gesture.isTracking && !dragging) {
                        val target = gesture.onCancel()
                        applyProgress(target)
                    }
                    false
                }

                else -> false
            }
        }

        private fun handleTouch(event: MotionEvent): Boolean {
            return when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    beginGesture(event)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val decision = gesture.onMove(event.x, event.y, event.eventTime)
                    if (decision != HomeSidePanelGestureDecision.PASS) {
                        dragging = decision == HomeSidePanelGestureDecision.CONSUME
                        applyProgress(gesture.progress)
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    val from = renderedProgress
                    val target = gesture.onUp(event.eventTime)
                    dragging = false
                    parent.requestDisallowInterceptTouchEvent(false)
                    animateTo(target, from, oneShot = target == 0f)
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    val from = renderedProgress
                    val target = gesture.onCancel()
                    dragging = false
                    parent.requestDisallowInterceptTouchEvent(false)
                    animateTo(target, from, oneShot = target == 0f)
                    true
                }

                else -> renderedProgress > CLOSED_EPSILON
            }
        }

        private fun beginGesture(event: MotionEvent) {
            requestSync(SYNC_HIERARCHY or SYNC_GEOMETRY)
            animator?.cancel()
            animator = null
            gesture.snapTo(renderedProgress)
            gesture.onDown(
                x = event.x,
                y = event.y,
                widthPx = parent.width.toFloat(),
                timeMs = event.eventTime,
            )
            dragging = false
            if (renderedProgress > CLOSED_EPSILON) overlayRoot.visibility = View.VISIBLE
        }

        private fun animateTo(
            target: Float,
            from: Float = renderedProgress,
            oneShot: Boolean = false,
            afterClosed: (() -> Unit)? = null,
        ) {
            requestSync(SYNC_HIERARCHY or SYNC_GEOMETRY)
            animator?.cancel()
            animator = null
            if (kotlin.math.abs(from - target) < 0.001f) {
                gesture.snapTo(target)
                applyProgress(target)
                afterClosed?.invoke()
                return
            }
            overlayRoot.visibility = View.VISIBLE
            var canceled = false
            animator = ValueAnimator.ofFloat(from, target).apply {
                duration = if (oneShot && target == 0f) {
                    (120L + 120L * kotlin.math.abs(from - target)).roundToInt().toLong()
                } else {
                    (180L + 180L * kotlin.math.abs(from - target)).roundToInt().toLong()
                }
                interpolator = DecelerateInterpolator(1.4f)
                addUpdateListener {
                    val progress = it.animatedValue as Float
                    gesture.snapTo(progress)
                    applyProgress(progress)
                }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationCancel(animation: Animator) {
                        canceled = true
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        if (canceled) return
                        gesture.snapTo(target)
                        applyProgress(target)
                        if (animator === animation) animator = null
                        afterClosed?.invoke()
                    }
                })
                start()
            }
        }

        private fun resolveExternalChrome() {
            val actionBarCandidates = linkedSetOf<View>()
            collectViews(decorRoot, actionBarCandidates) {
                it.javaClass.name == "androidx.appcompat.widget.ActionBarContainer"
            }
            val staleActionBars = actionBarContainers.filter { it !in actionBarCandidates }
            staleActionBars.forEach { actionBar ->
                unobserveView(actionBar)
                restoreActionBarTransform(actionBar)
                actionBarContainers.remove(actionBar)
            }
            actionBarCandidates.forEach { observeView(it, SYNC_GEOMETRY) }
            actionBarContainers += actionBarCandidates
            // v268 还原版 FAB 不再暴露 hostViewFor：负一屏与 FAB 的融合（把 FAB 移入内容包装）暂时停用
            val fabCandidate: View? = null
            if (fabHostView !== fabCandidate) {
                fabHostView?.let(::unobserveView)
                if (fabHostView?.parent == null && fabCandidate == null) {
                    fabHostView = null
                    fabOriginalParent = null
                    fabOriginalLayoutParams = null
                    fabOriginalIndex = -1
                } else {
                    restoreFabHostToOriginalParent()
                }
            }
            if (fabCandidate != null) {
                observeView(fabCandidate, SYNC_HIERARCHY or SYNC_GEOMETRY)
            }
            if (fabCandidate != null && fabHostView !== fabCandidate) {
                moveFabHostIntoContentWrapper(fabCandidate)
            }
            if (
                fabCandidate != null &&
                homeSidePanelShouldReparentExternalChrome(
                    progress = renderedProgress,
                    isCurrentHost = fabHostView === fabCandidate,
                    isInContentWrapper = fabCandidate.parent === contentWrapper,
                    parentClassName = fabCandidate.parent.javaClass.name,
                )
            ) {
                moveFabHostIntoContentWrapper(fabCandidate)
            }
        }

        private fun syncToolbarProfileBindings() {
            chattingVisible = isChattingVisible()
            val hosts = linkedMapOf<RelativeLayout, TextView>()
            collectToolbarProfileHosts(decorRoot, hosts)
            val staleObservedHosts = observedToolbarProfileHosts.filter { it !in hosts }
            staleObservedHosts.forEach { host ->
                unobserveView(host)
                observedToolbarProfileHosts.remove(host)
            }
            hosts.keys.forEach { host ->
                observeView(host, SYNC_HIERARCHY)
                observedToolbarProfileHosts += host
            }
            chattingToolbarHosts.removeAll { it.parent == null }
            if (chattingVisible) {
                chattingToolbarHosts += hosts.keys.filterNot { it in toolbarProfileBindings }
            }

            val iterator = toolbarProfileBindings.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next()
                if (entry.key !in hosts || entry.value.composeView.parent !== entry.key) {
                    if (entry.key !in hosts) unobserveView(entry.key)
                    disposeToolbarProfileBinding(entry.value)
                    iterator.remove()
                }
            }

            hosts.forEach { (host, nativeTitle) ->
                if (
                    !chattingVisible &&
                    (host in homeToolbarHosts || host !in chattingToolbarHosts) &&
                    host !in toolbarProfileBindings
                ) {
                    homeToolbarHosts += host
                    toolbarProfileBindings[host] = createToolbarProfileBinding(host, nativeTitle)
                }
            }
            syncToolbarProfileVisibility()
            if (chattingVisible && renderedProgress > CLOSED_EPSILON) {
                close(animated = true, oneShot = true)
            }
        }

        private fun isChattingVisible(): Boolean {
            // WeKit 直接读 LauncherUI.currentFragmet (8.0.65-8.0.71 的拼写错误字段名)。
            // 8.0.76 已移除该字段, 直接访问会抛 NoSuchMethodError (编译成 getCurrentFragmet() 调用),
            // 且该函数在主线程 Handler 回调里执行, 会直接崩微信。
            // 这里沿类层次反射查找, 缺失时视为不在聊天页。
            return try {
                var current: Class<*>? = activity.javaClass
                while (current != null) {
                    try {
                        val field = current.getDeclaredField("currentFragmet")
                        field.isAccessible = true
                        if (field.get(activity) != null) return true
                    } catch (_: NoSuchFieldException) {
                        // fall through to superclass
                    }
                    current = current.superclass
                }
                false
            } catch (e: Throwable) {
                WeLogger.w(TAG, "read LauncherUI.currentFragmet failed (8.0.76+ may have removed it)", e)
                false
            }
        }

        private fun collectToolbarProfileHosts(
            view: View,
            destination: MutableMap<RelativeLayout, TextView>,
        ) {
            val titles = mutableListOf<View>()
            collectViews(view, titles) { it is TextView && it.id == android.R.id.text1 }
            titles.forEach { titleView ->
                val title = titleView as TextView
                var customRoot: View = title
                var ancestor = title.parent
                while (ancestor is ViewGroup) {
                    if (ancestor.isToolbar()) {
                        destination[customRoot as RelativeLayout] = title
                        break
                    }
                    customRoot = ancestor
                    ancestor = ancestor.parent
                }
            }
        }

        private fun View.isToolbar(): Boolean {
            var type: Class<*>? = javaClass
            while (type != null) {
                if (type.name == "androidx.appcompat.widget.Toolbar") return true
                type = type.superclass
            }
            return false
        }

        private fun collectViews(
            view: View,
            destination: MutableCollection<View>,
            predicate: (View) -> Boolean,
        ) {
            if (predicate(view)) destination += view
            if (view !is ViewGroup) return
            for (index in 0 until view.childCount) {
                collectViews(view.getChildAt(index), destination, predicate)
            }
        }

        private fun observeView(view: View, flags: Int) {
            if (observedViews.containsKey(view)) return
            val attachListener = object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(view: View) {
                    requestSync(flags)
                }

                override fun onViewDetachedFromWindow(view: View) {
                    unobserveView(view)
                    requestSync(SYNC_HIERARCHY or SYNC_INSETS)
                }
            }
            val layoutListener = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
                requestSync(flags)
            }
            view.addOnAttachStateChangeListener(attachListener)
            view.addOnLayoutChangeListener(layoutListener)
            observedViews[view] = ObservedViewListeners(attachListener, layoutListener)
        }

        private fun unobserveView(view: View) {
            val listeners = observedViews.remove(view) ?: return
            view.removeOnAttachStateChangeListener(listeners.attach)
            view.removeOnLayoutChangeListener(listeners.layout)
        }

        private fun createToolbarProfileBinding(
            host: RelativeLayout,
            nativeTitle: TextView,
        ): ToolbarProfileBinding {
            val composeView = ComposeView(activity).apply {
                setBackgroundColor(AndroidColor.TRANSPARENT)
                setLifecycleOwner(LifecycleOwnerProvider.getOrCreate(activity))
                setContent {
                    InjectedUiTheme {
                        val state by panelState.uiState.collectAsStateWithLifecycle()
                        HomeSidePanelToolbarContent(
                            profile = state.profile,
                            onAvatarClick = ::open,
                            onStatusClick = panelState::openStatusEditorFromToolbar,
                        )
                    }
                }
            }
            host.addView(
                composeView,
                RelativeLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                ).apply {
                    addRule(RelativeLayout.ALIGN_PARENT_START)
                    addRule(RelativeLayout.CENTER_VERTICAL)
                },
            )
            return ToolbarProfileBinding(host, nativeTitle, composeView)
        }

        private fun syncToolbarProfileVisibility() {
            val state = panelState.uiState.value
            val showProfile = state.showToolbarProfile && selectedTabIndex == HOME_TAB_INDEX
            toolbarProfileBindings.values.forEach { binding ->
                binding.composeView.visibility = if (showProfile) View.VISIBLE else View.GONE
            }
            syncNativeTitleVisibility(
                bindings = toolbarProfileBindings.values,
                hide = showProfile && state.hideWeChatTitle,
            )
        }

        private fun syncNativeTitleVisibility(
            bindings: Collection<ToolbarProfileBinding>,
            hide: Boolean,
        ) {
            val currentTitles = bindings.mapTo(linkedSetOf()) { it.nativeTitle }
            val iterator = nativeTitleVisibilities.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next()
                if (!hide || entry.key !in currentTitles) {
                    entry.key.visibility = entry.value
                    iterator.remove()
                }
            }
            if (!hide) return
            currentTitles.forEach { title ->
                nativeTitleVisibilities.putIfAbsent(title, title.visibility)
                title.visibility = View.GONE
            }
        }

        private fun clearToolbarProfileBindings() {
            nativeTitleVisibilities.forEach { (title, visibility) ->
                title.visibility = visibility
            }
            nativeTitleVisibilities.clear()
            toolbarProfileBindings.values.forEach(::disposeToolbarProfileBinding)
            toolbarProfileBindings.clear()
        }

        private fun disposeToolbarProfileBinding(binding: ToolbarProfileBinding) {
            if (binding.composeView.parent === binding.host) {
                binding.host.removeView(binding.composeView)
            }
            binding.composeView.disposeComposition()
        }

        private fun applyProgress(progress: Float) {
            val p = progress.coerceIn(0f, 1f)
            val becameVisible = !wasPanelVisible && p > CLOSED_EPSILON
            val becameHidden = wasPanelVisible && p <= CLOSED_EPSILON
            renderedProgress = p
            if (becameVisible) panelState.onPanelOpened()
            if (becameHidden) panelState.onPanelClosed()
            wasPanelVisible = p > CLOSED_EPSILON

            val transform = homeSidePanelVisualTransform(
                progress = p,
                density = activity.resources.displayMetrics.density,
            )

            contentWrapper.pivotX = contentWrapper.width / 2f
            contentWrapper.pivotY = contentWrapper.height / 2f
            contentWrapper.scaleX = transform.scale
            contentWrapper.scaleY = transform.scale
            contentWrapper.translationX = transform.translationXPx
            contentWrapper.translationY = transform.translationYPx
            // invalidateOutline 每帧调用会重算轮廓阴影，半径变化不到半个像素就别刷。
            val radiusPx = 28.dpToPx(activity).toFloat() * transform.easedProgress
            if (abs(outlineProvider.radiusPx - radiusPx) > 0.5f) {
                outlineProvider.radiusPx = radiusPx
                contentWrapper.invalidateOutline()
            }

            if (p > CLOSED_EPSILON) {
                fabHostView?.let { moveFabHostIntoContentWrapper(it) }
            }
            applyActionBarProgress(p, transform)

            dimView.alpha = DIM_MAX_ALPHA * transform.easedProgress
            dimView.isClickable = p > CLOSED_EPSILON

            panelView.translationX = -drawerWidthPx * (1f - p)
            overlayRoot.isClickable = p > CLOSED_EPSILON || dragging
            overlayRoot.visibility = if (p > CLOSED_EPSILON || dragging) View.VISIBLE else View.GONE
            // bringToFront() 每次都会在父容器里摘掉再插回去并触发 requestLayout，
            // 放进逐帧动画里就是持续掉帧。只在刚变可见时抬一次。
            if (becameVisible) overlayRoot.bringToFront()
        }

        /** 侧滑栏背景图（主题包里的 wallpaper_panel.png），透明度由 theme_panel_alpha 控制。 */
        /**
         * 侧滑栏背景图曾取自「主题工坊」的自定义主题包（ThemePack）。
         * 主题已回退到「主题商城」+ 6 款内置主题，不再有主题包，这里直接保持无背景。
         */
        private fun applyPanelBackground() {
            panelBgView.setImageDrawable(null)
            panelBgView.alpha = 0f
        }

        private fun updateDrawerWidth(): Boolean {
            val width = parent.width
            if (width <= 0) return false
            val nextWidth = (width * DRAWER_WIDTH_FRACTION).roundToInt().coerceAtLeast(1)
            if (nextWidth == drawerWidthPx) return false
            drawerWidthPx = nextWidth
            val params = panelView.layoutParams as? FrameLayout.LayoutParams
                ?: FrameLayout.LayoutParams(drawerWidthPx, FrameLayout.LayoutParams.MATCH_PARENT)
            params.width = drawerWidthPx
            params.height = FrameLayout.LayoutParams.MATCH_PARENT
            panelView.layoutParams = params
            (panelBgView.layoutParams as? FrameLayout.LayoutParams)?.let { bgParams ->
                bgParams.width = drawerWidthPx
                panelBgView.layoutParams = bgParams
            }
            return true
        }

        private fun applyActionBarProgress(
            progress: Float,
            transform: HomeSidePanelVisualTransform = homeSidePanelVisualTransform(
                progress = progress,
                density = activity.resources.displayMetrics.density,
            ),
        ) {
            if (progress <= CLOSED_EPSILON) {
                restoreActionBarTransform()
                return
            }
            actionBarContainers.forEach { actionBar ->
                val snapshot = actionBarTransformSnapshots.getOrPut(actionBar) {
                    captureActionBarTransform(actionBar)
                }
                if (actionBar.pivotX != snapshot.transformPivotX) {
                    actionBar.pivotX = snapshot.transformPivotX
                }
                if (actionBar.pivotY != snapshot.transformPivotY) {
                    actionBar.pivotY = snapshot.transformPivotY
                }
                val scaleX = snapshot.scaleX * transform.scale
                val scaleY = snapshot.scaleY * transform.scale
                val translationX = snapshot.translationX + transform.translationXPx
                val translationY = snapshot.translationY + transform.translationYPx
                if (actionBar.scaleX != scaleX) actionBar.scaleX = scaleX
                if (actionBar.scaleY != scaleY) actionBar.scaleY = scaleY
                if (actionBar.translationX != translationX) actionBar.translationX = translationX
                if (actionBar.translationY != translationY) actionBar.translationY = translationY
            }
        }

        private fun captureActionBarTransform(actionBar: View): ActionBarTransformSnapshot {
            val parentLocation = IntArray(2)
            val actionBarLocation = IntArray(2)
            parent.getLocationOnScreen(parentLocation)
            actionBar.getLocationOnScreen(actionBarLocation)
            return ActionBarTransformSnapshot(
                originalPivotX = actionBar.pivotX,
                originalPivotY = actionBar.pivotY,
                transformPivotX = parentLocation[0] + parent.width / 2f - actionBarLocation[0],
                transformPivotY = parentLocation[1] + parent.height / 2f - actionBarLocation[1],
                scaleX = actionBar.scaleX,
                scaleY = actionBar.scaleY,
                translationX = actionBar.translationX,
                translationY = actionBar.translationY,
            )
        }

        private fun restoreActionBarTransform() {
            actionBarTransformSnapshots.forEach { (actionBar, snapshot) ->
                restoreActionBarTransform(actionBar, snapshot)
            }
            actionBarTransformSnapshots.clear()
        }

        private fun restoreActionBarTransform(actionBar: View) {
            val snapshot = actionBarTransformSnapshots.remove(actionBar) ?: return
            restoreActionBarTransform(actionBar, snapshot)
        }

        private fun restoreActionBarTransform(
            actionBar: View,
            snapshot: ActionBarTransformSnapshot,
        ) {
            actionBar.pivotX = snapshot.originalPivotX
            actionBar.pivotY = snapshot.originalPivotY
            actionBar.scaleX = snapshot.scaleX
            actionBar.scaleY = snapshot.scaleY
            actionBar.translationX = snapshot.translationX
            actionBar.translationY = snapshot.translationY
        }

        private fun moveFabHostIntoContentWrapper(host: View) {
            val currentParent = host.parent as? ViewGroup ?: return
            if (currentParent === contentWrapper) {
                fabHostView = host
                return
            }
            fabOriginalParent = currentParent
            fabOriginalLayoutParams = host.layoutParams
            fabOriginalIndex = currentParent.indexOfChild(host)
            currentParent.removeView(host)
            contentWrapper.addView(
                host,
                fabOriginalLayoutParams ?: FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                ),
            )
            fabHostView = host
        }

        private fun restoreFabHostToOriginalParent() {
            val host = fabHostView ?: return
            val originalParent = fabOriginalParent
            if (host.parent === contentWrapper) {
                contentWrapper.removeView(host)
            }
            if (originalParent != null && host.parent !== originalParent) {
                val index = fabOriginalIndex.coerceIn(0, originalParent.childCount)
                originalParent.addView(
                    host,
                    index,
                    fabOriginalLayoutParams ?: FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT,
                    ),
                )
            }
            fabHostView = null
            fabOriginalParent = null
            fabOriginalLayoutParams = null
            fabOriginalIndex = -1
        }

        private fun moveExistingChildrenIntoWrapper() {
            val children = buildList {
                for (i in 0 until parent.childCount) {
                    val child = parent.getChildAt(i)
                    if (child !== contentWrapper) {
                        add(child to child.layoutParams)
                    }
                }
            }
            children.forEach { (child, params) ->
                parent.removeView(child)
                contentWrapper.addView(child, params)
            }
        }

        private fun absorbStrayChildren() {
            var index = 0
            while (index < parent.childCount) {
                val child = parent.getChildAt(index)
                if (child === contentWrapper) {
                    index++
                } else {
                    val params = child.layoutParams
                    parent.removeViewAt(index)
                    contentWrapper.addView(child, params)
                }
            }
            if (decorRoot.indexOfChild(overlayRoot) != decorRoot.childCount - 1) {
                overlayRoot.bringToFront()
            }
        }

        private fun restoreContent() {
            while (contentWrapper.isNotEmpty()) {
                val child = contentWrapper.getChildAt(0)
                val params = child.layoutParams
                contentWrapper.removeViewAt(0)
                parent.addView(child, params)
            }
            contentWrapper.scaleX = 1f
            contentWrapper.scaleY = 1f
            contentWrapper.translationX = 0f
            contentWrapper.translationY = 0f
        }

        private fun isInsidePanel(x: Float): Boolean =
            x <= drawerWidthPx
    }

    private class HomeSidePanelOverlayLayout(context: Context) : FrameLayout(context) {
        var session: HomeSidePanelSession? = null

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean =
            session?.onOverlayInterceptTouch(ev) == true || super.onInterceptTouchEvent(ev)

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent): Boolean =
            session?.onOverlayTouch(event) == true || super.onTouchEvent(event)
    }

    private class ProgressOutlineProvider : ViewOutlineProvider() {
        var radiusPx: Float = 0f

        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }

    private const val HOME_TAB_INDEX = 0
    private const val SYNC_HIERARCHY = 1
    private const val SYNC_GEOMETRY = 1 shl 1
    private const val SYNC_INSETS = 1 shl 2
    private const val SYNC_ALL = SYNC_HIERARCHY or SYNC_GEOMETRY or SYNC_INSETS
    private const val DRAWER_WIDTH_FRACTION = 0.84f
    private const val DIM_MAX_ALPHA = 0.52f
    private const val CLOSED_EPSILON = 0.001f
    private const val PAGE_SETTLED_EPSILON = 0.001f
}

private val homeSidePanelHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .build()
}
