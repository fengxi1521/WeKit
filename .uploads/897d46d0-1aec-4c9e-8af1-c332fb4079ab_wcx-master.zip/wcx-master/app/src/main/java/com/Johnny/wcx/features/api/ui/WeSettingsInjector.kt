package com.Johnny.wcx.features.api.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import com.tencent.mm.plugin.setting.ui.setting.SettingsUI
import com.tencent.mm.plugin.setting.ui.setting_new.base.BaseSettingPrefUI
import com.tencent.mm.plugin.setting.ui.setting_new.base.BaseSettingUI
import com.tencent.mm.plugin.setting.ui.setting_new.settings.SettingAdditionHeaderSearch
import com.tencent.mm.plugin.setting.ui.setting_new.settings.SettingGroupAccountInfo
import com.tencent.mm.plugin.setting.ui.setting_new.settings.SettingGroupMain
import com.tencent.mm.plugin.setting.ui.setting_new.settings.SettingGroupPersonalInfo
import com.tencent.mm.pluginsdk.ui.chat.ChatFooter
import com.tencent.mm.ui.LauncherUI
import com.tencent.mm.ui.base.preference.IconPreference
import dev.ujhhgtg.reflekt.reflekt
import dev.ujhhgtg.reflekt.utils.isBuiltin
import dev.ujhhgtg.reflekt.utils.toClassOrNull
import com.Johnny.wcx.BuildConfig
import com.Johnny.wcx.activity.settings.SettingsActivity
import com.Johnny.wcx.constants.PackageNames
import com.Johnny.wcx.dexkit.abc.IResolveDex
import com.Johnny.wcx.dexkit.dsl.dexClass
import com.Johnny.wcx.dexkit.dsl.dexMethod
import com.Johnny.wcx.features.core.ApiFeature
import com.Johnny.wcx.features.core.Feature
import com.Johnny.wcx.utils.WeLogger
import com.Johnny.wcx.utils.reflection.bool
import com.Johnny.wcx.utils.reflection.int
import org.luckypray.dexkit.DexKitBridge
import org.luckypray.dexkit.query.enums.StringMatchType
import java.lang.reflect.Modifier

@Feature(name = "设置模块入口", categories = ["API"])
object WeSettingsInjector : ApiFeature(), IResolveDex, WeChatInputBarApi.IInputBarListener {

    private val methodSetKey by dexMethod()
    private val methodSetTitle by dexMethod()
    private val methodGetKey by dexMethod()
    private val methodAddPref by dexMethod()

    // modern method
    private val classSettingItemClassesProvider by dexClass(allowFailure = true) {
        matcher {
            usingEqStrings("Repairer_Setting")

            superClass {
                usingEqStrings("type")
            }
        }
    }
    private val classBaseSettingItem by dexClass(allowFailure = true) {
        matcher {
            usingEqStrings("", "activity", "context", "intent")

            addMethod {
                name = "<init>"
                paramTypes("androidx.appcompat.app.AppCompatActivity")
            }

            addInterface {
                className("com.tencent.mm.plugin.newtips.model", StringMatchType.StartsWith)
            }
        }
    }
    private val classBaseSettingSwitchItem by dexClass(allowFailure = true) {
        matcher {
            usingEqStrings("activity", "context", "itemView", "1", "0")

            addMethod {
                returnType = "int"
                usingNumbers(2)
            }

            addMethod {
                name = "<init>"
                paramTypes("androidx.appcompat.app.AppCompatActivity")
                usingNumbers(1)
            }

            superClass {
                usingEqStrings("activity")
            }
        }
    }
    private val classSettingLocation by dexClass(allowFailure = true) {
        matcher {
            usingEqStrings(", frontItem=")
        }
    }
    private val methodSettingGroupAccountInfoGetStringId by dexMethod(allowFailure = true) {
        matcher {
            declaredClass = "com.tencent.mm.plugin.setting.ui.setting_new.settings.SettingGroupAccountInfo"
            usingEqStrings("SettingGroup_Main_AccountInfo")
            returnType = "java.lang.String"
        }
    }
    private val methodSettingGroupAccountInfoReturns1 by dexMethod(allowFailure = true) {
        matcher {
            declaredClass = "com.tencent.mm.plugin.setting.ui.setting_new.settings.SettingGroupAccountInfo"
            usingNumbers(1)
            returnType = "int"
        }
    }
    private val methodSettingGroupPersonalInfoGetGroupNameResId by dexMethod(allowFailure = true) {
        matcher {
            declaredClass = "com.tencent.mm.plugin.setting.ui.setting_new.settings.SettingGroupPersonalInfo"
            returnType = "java.lang.Integer"
        }
    }
    private val methodResourceHelperGetStringById by dexMethod(allowFailure = true) {
        matcher {
            usingEqStrings("MicroMsg.ResourceHelper", "get string, resId %d, but context is null")
        }
    }
    private const val TAG = "WeSettingsInjector"

    private const val PREFS_KEY = "wekit_settings_entry"
    private const val PREFS_TITLE = "${BuildConfig.TAG} 设置"
    private const val PREFERENCE_CLASS_NAME = "com.tencent.mm.ui.base.preference.Preference"

    @SuppressLint("NonUniqueDexKitData")
    override fun resolveDex(dexKit: DexKitBridge) {
        val prefClass = dexKit.findClass {
            matcher { className = PREFERENCE_CLASS_NAME }
        }.single()

        methodSetKey.find(dexKit, allowMultiple = true) {
            searchPackages("com.tencent.mm.ui.base.preference")
            matcher {
                declaredClass = PREFERENCE_CLASS_NAME
                returnType = "void"
                paramTypes("java.lang.String")
                usingStrings("Preference")
            }
        }

        val setTitleCandidates = prefClass.findMethod {
            matcher {
                returnType = "void"
                paramTypes("java.lang.CharSequence")
            }
        }
        if (setTitleCandidates.isNotEmpty()) {
            methodSetTitle.setDescriptor(setTitleCandidates.last())
        }

        val getKeyCandidates = prefClass.findMethod {
            matcher {
                paramCount = 0
                returnType = "java.lang.String"
            }
        }

        val targetGetKey = getKeyCandidates.firstOrNull { it.name != "toString" }

        if (targetGetKey != null) {
            methodGetKey.setDescriptor(targetGetKey)
        }

        val adapterClass = dexKit.findClass {
            searchPackages("com.tencent.mm.ui.base.preference")
            matcher {
                superClass = "android.widget.BaseAdapter"
                methods {
                    add {
                        modifiers = Modifier.PUBLIC
                        name = "getView"
                        paramCount = 3
                    }
                    add {
                        name = "<init>"
                        paramCount = 3
                    }
                }
            }
        }.singleOrNull()

        if (adapterClass != null) {
            methodAddPref.find(dexKit, allowMultiple = true) {
                searchPackages("com.tencent.mm.ui.base.preference")
                matcher {
                    declaredClass = adapterClass.name
                    paramTypes(PREFERENCE_CLASS_NAME, "int")
                    returnType = "void"
                }
            }
        }
    }

    override fun onEnable() {
        runCatching {
            hookLauncherUi()
        }.onFailure { WeLogger.w(TAG, "failed to hook LauncherUI") }

        WeChatInputBarApi.addListener(this)

        runCatching {
            injectLegacy()
        }.onFailure { WeLogger.w(TAG, "failed to inject into legacy settings") }

        runCatching {
            injectModern()
        }.onFailure { WeLogger.w(TAG, "failed to inject into modern settings") }
    }

    override fun onDisable() {
        WeChatInputBarApi.removeListener(this)
    }

    override fun onTextChanged(chatFooter: ChatFooter, text: String) {
        if (text != "#wcx") return
        chatFooter.lastText = ""
        openSettingsDialog(chatFooter.context)
    }

    private fun injectLegacy() {
        val clsSettingsUi = "${PackageNames.WECHAT}.plugin.setting.ui.setting.SettingsUI"
            .toClassOrNull() ?: run {
            WeLogger.w(TAG, "legacy settings class not found, skipping")
            return
        }

        clsSettingsUi.reflekt().firstMethod {
            name = "initView"
            parameterCount = 0
        }.hookAfter {
            val context = thisObject as SettingsUI

            try {
                val prefInstance = IconPreference(context)

                methodSetKey.method.invoke(prefInstance, PREFS_KEY)
                methodSetTitle.method.invoke(prefInstance, PREFS_TITLE)

                val prefScreen = context.reflekt().invokeMethod("getPreferenceScreen", superclass = true)

                methodAddPref.method.invoke(prefScreen, prefInstance, 0)

            } catch (e: Throwable) {
                WeLogger.e(TAG, "failed to insert pref item", e)
            }
        }

        clsSettingsUi.reflekt().firstMethod { name = "onPreferenceTreeClick" }
            .hookBefore {
                try {
                    if (args.size < 2) return@hookBefore
                    val preference = args[1] ?: return@hookBefore

                    val key = methodGetKey.method.invoke(preference) as? String

                    if (PREFS_KEY == key) {
                        val activity = thisObject as Activity

                        openSettingsDialog(activity)

                        try {
                            // 仅当原方法返回 boolean 时才设置 result = true
                            if (method is java.lang.reflect.Method) {
                                val returnType = (method as java.lang.reflect.Method).returnType
                                if (returnType == Boolean::class.javaPrimitiveType || returnType == java.lang.Boolean::class.java) {
                                    result = true
                                }
                            }
                        } catch (e: Throwable) {
                            // 兜底异常捕获，防止单条 Hook 异常导致微信主线程崩溃
                        }
                    }
                } catch (e: Throwable) {
                    WeLogger.e(TAG, "onPreferenceTreeClick hook 异常", e)
                }
            }
    }

    private lateinit var mGetPageGroupItemClass: String
    private lateinit var mGetLevel: String
    private lateinit var mOnClick: String
    private lateinit var mGetKey: String
    private lateinit var mGetSettingLocation: String
    private lateinit var mGetNameResId: String
    private lateinit var mGetGroupNameResId: String
    private lateinit var mGetSwitchState: String
    private lateinit var mGetSwitchProperty: String

    private fun resolveMethodNames() {
        if (::mGetPageGroupItemClass.isInitialized) return

        // this is only used for resolving method names, so we'll hard-code SettingGroupAccountInfo
        SettingGroupAccountInfo::class.java.declaredMethods.run {
            mGetPageGroupItemClass = first { m -> m.returnType == Class::class.java }.name
            mGetLevel = methodSettingGroupAccountInfoReturns1.method.name
            mOnClick = first { m -> m.parameterCount == 3 }.name
            mGetKey = methodSettingGroupAccountInfoGetStringId.method.name
            mGetSettingLocation =
                last { m -> m.returnType == classSettingLocation.clazz }.name
            mGetNameResId =
                last { m ->
                    m.returnType == int &&
                            m.name != methodSettingGroupAccountInfoReturns1.method.name
                }.name
            mGetGroupNameResId = methodSettingGroupPersonalInfoGetGroupNameResId.method.name
            mGetSwitchState = classBaseSettingSwitchItem.reflekt().firstMethod {
                modifiers(Modifier.ABSTRACT)
                returnType = bool
            }.name
            mGetSwitchProperty = classBaseSettingSwitchItem.reflekt().firstMethod {
                modifiers(Modifier.ABSTRACT)
                returnType { !it.isBuiltin }
            }.name

            // non-play 8.0.69: C6, K6, Q6, w6, x6, z6, u6, W6, V6
            // non-play 8.0.70: k7, r7, w7, g7, h7, j7, ...
            // non-play 8.0.71: p7, w7, B7, l7, m7, o7, ...
            // play 8.0.69 (3022): E6, N6, U6, A6, B6, D6, ...
            WeLogger.d(
                TAG,
                "resolved all method names: $mGetPageGroupItemClass, $mGetLevel, $mOnClick, $mGetKey, $mGetSettingLocation, $mGetNameResId, $mGetGroupNameResId, " +
                        "$mGetSwitchState, $mGetSwitchProperty"
            )
        }
    }

    private fun injectModern() {
        "${PackageNames.WECHAT}.plugin.setting.ui.setting_new.settings.SettingGroupMain".toClassOrNull()
            ?: run {
                WeLogger.w(TAG, "modern settings class not found, skipping")
                return
            }

        resolveMethodNames()

        val settingsManager = WeChatSettingsManager(
            classBaseSettingItem.clazz, classBaseSettingSwitchItem.clazz, classSettingLocation.clazz, classSettingItemClassesProvider.clazz,
            BaseSettingPrefUI::class.java, BaseSettingUI::class.java, methodResourceHelperGetStringById.method,
            mGetPageGroupItemClass, mGetLevel, mOnClick, mGetKey, mGetSettingLocation, mGetNameResId, mGetGroupNameResId, mGetSwitchState, mGetSwitchProperty
        )

        settingsManager.createItem {
            key = "SettingGroup_Main_WeKitTest1"
            title = "WCX 设置"
            level = 1
            groupTitle = "插件"
            pageClass = SettingGroupMain::class.java
            parentClass = SettingAdditionHeaderSearch::class.java
            childClass = SettingGroupPersonalInfo::class.java
            onClick = {
                try {
                    openSettingsDialog(it)
                } catch (e: Throwable) {
                    WeLogger.e(TAG, "modern settings onClick 异常", e)
                }
            }
        }
        settingsManager.install()
    }

    private fun hookLauncherUi() {
        LauncherUI::class.reflekt().apply {
            firstMethod { name = "onCreate" }
                .hookBefore {
                    try {
                        val activity = thisObject as Activity
                        val intent = activity.intent ?: return@hookBefore
                        intent.getStringExtra(BuildConfig.TAG) ?: return@hookBefore
                        // wait for resources & theme to init
                        Handler(Looper.getMainLooper()).postDelayed({
                            openSettingsDialog(activity)
                        }, 500)
                    } catch (e: Throwable) {
                        WeLogger.e(TAG, "hookLauncherUi onCreate 异常", e)
                    }
                }

            firstMethod { name = "onNewIntent" }
                .hookBefore {
                    try {
                        val activity = thisObject as Activity
                        val intent = activity.intent ?: return@hookBefore
                        intent.getStringExtra(BuildConfig.TAG) ?: return@hookBefore
                        openSettingsDialog(activity)
                    } catch (e: Throwable) {
                        WeLogger.e(TAG, "hookLauncherUi onNewIntent 异常", e)
                    }
                }
        }
    }

    @Suppress("NOTHING_TO_INLINE")
    fun openSettingsDialog(context: Context) {
        // Bug Fix (v201): 对齐上游 WeKit 的最简 Intent 启动方式。
        // 配合 WeLauncher.init() 中 ActivityProxy.init() 注入的 IActivityManager /
        // Instrumentation / Handler.Callback 钩子，模块 Activity 会被代理到
        // WeChatSplashActivity 中转并最终通过 setClassName 启动真实 Activity。
        // ActivityProxy.ActProxyMgr.isModuleProxyActivity() 通过
        //   className.startsWith(PackageNames.MODULE)
        // 判定模块 Activity 并走代理路由；manifest 中 SettingsActivity
        // 已声明 exported="true"，因此经代理路由后能正常拉起。
        try {
            context.startActivity(Intent(context, SettingsActivity::class.java))
        } catch (e: Throwable) {
            WeLogger.e(TAG, "openSettingsDialog 启动失败", e)
        }
    }
}
