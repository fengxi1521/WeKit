package com.Johnny.wcx.activity.settings

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.annotation.Keep
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalResources
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.composables.icons.materialsymbols.MaterialSymbols
import com.composables.icons.materialsymbols.outlined.Account_circle
import com.composables.icons.materialsymbols.outlined.Add_circle
import com.composables.icons.materialsymbols.outlined.Article
import com.composables.icons.materialsymbols.outlined.Bug_report
import com.composables.icons.materialsymbols.outlined.Call
import com.composables.icons.materialsymbols.outlined.Camera
import com.composables.icons.materialsymbols.outlined.Chat
import com.composables.icons.materialsymbols.outlined.Checklist
import com.composables.icons.materialsymbols.outlined.Comedy_mask
import com.composables.icons.materialsymbols.outlined.Contact_page
import com.composables.icons.materialsymbols.outlined.Contacts
import com.composables.icons.materialsymbols.outlined.Home
import com.composables.icons.materialsymbols.outlined.Imagesearch_roller
import com.composables.icons.materialsymbols.outlined.Movie
import com.composables.icons.materialsymbols.outlined.Newspaper
import com.composables.icons.materialsymbols.outlined.Notifications
import com.composables.icons.materialsymbols.outlined.Package_2
import com.composables.icons.materialsymbols.outlined.Payments
import com.composables.icons.materialsymbols.outlined.Settings
import com.composables.icons.materialsymbols.outlined.Terminal
import com.composables.icons.materialsymbols.outlined.Tune
import com.composables.icons.materialsymbols.outlined.Wand_stars
import com.composables.icons.materialsymbols.outlinedfilled.Article
import com.composables.icons.materialsymbols.outlinedfilled.Home
import com.composables.icons.materialsymbols.outlinedfilled.Settings
import com.composables.icons.materialsymbols.outlinedfilled.Tune
import com.Johnny.wcx.features.core.BaseFeature
import com.Johnny.wcx.features.core.ClickableFeature
import com.Johnny.wcx.features.core.SwitchFeature
import com.Johnny.wcx.preferences.WePrefs
import com.Johnny.wcx.ui.content.FloatingBottomBar
import com.Johnny.wcx.ui.content.FloatingBottomBarDefaults
import com.Johnny.wcx.ui.content.FloatingBottomBarItem
import com.Johnny.wcx.ui.content.MiuixStackNavigator
import com.Johnny.wcx.ui.content.liquid.vibrancy
import com.Johnny.wcx.ui.utils.CommonContextWrapper
import com.Johnny.wcx.ui.utils.theme.ModuleTheme
import com.Johnny.wcx.utils.WeLogger
import com.Johnny.wcx.utils.android.showToast
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.BasicComponent
import top.yukonga.miuix.kmp.basic.BasicComponentDefaults
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.CardDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Switch
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.blur.blur
import top.yukonga.miuix.kmp.blur.drawBackdrop
import top.yukonga.miuix.kmp.blur.layerBackdrop
import top.yukonga.miuix.kmp.blur.rememberLayerBackdrop
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.squircle.squircleSurface
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.utils.overScrollVertical
import top.yukonga.miuix.kmp.utils.scrollEndHaptic
import androidx.compose.material3.Icon as M3Icon
import androidx.compose.material3.Text as M3Text
import androidx.compose.ui.draw.clipToBounds

val LocalComponentActivity = staticCompositionLocalOf<ComponentActivity> { error("not provided") }

@Keep
class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val context = CommonContextWrapper(this)
        val resources = context.resources

        setContent {
            CompositionLocalProvider(
                LocalContext provides context,
                LocalResources provides resources,
                LocalActivity provides this,
                LocalComponentActivity provides this
            ) {
                ModuleTheme {
                    SettingsRoot(onFinish = { finish() })
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
//  Feature categories (name -> icon)
// ---------------------------------------------------------------------------

val FEATURE_CATEGORIES = listOf(
    "聊天" to MaterialSymbols.Outlined.Chat,
    "联系人与群组" to MaterialSymbols.Outlined.Contacts,
    "红包与支付" to MaterialSymbols.Outlined.Payments,
    "朋友圈" to MaterialSymbols.Outlined.Camera,
    "系统与隐私" to MaterialSymbols.Outlined.Wand_stars,
    "音视频通话" to MaterialSymbols.Outlined.Call,
    "通知" to MaterialSymbols.Outlined.Notifications,
    "界面美化" to MaterialSymbols.Outlined.Imagesearch_roller,
    "公众号" to MaterialSymbols.Outlined.Newspaper,
    "小程序" to MaterialSymbols.Outlined.Package_2,
    "视频号" to MaterialSymbols.Outlined.Movie,
    "个人资料" to MaterialSymbols.Outlined.Account_circle,
    "调试" to MaterialSymbols.Outlined.Bug_report,
    "脚本 (JS)" to MaterialSymbols.Outlined.Terminal,
    "脚本 (Java)" to MaterialSymbols.Outlined.Terminal,
    "娱乐" to MaterialSymbols.Outlined.Comedy_mask,
    "批量操作" to MaterialSymbols.Outlined.Checklist,
    "首页右上角菜单" to MaterialSymbols.Outlined.Add_circle,
    "联系人详情页面" to MaterialSymbols.Outlined.Contact_page,
    // 「密友功能」刻意放在列表**最后**（隐蔽入口，不显眼）；搜索页会排除该分类。
    "密友功能" to MaterialSymbols.Outlined.Contacts,
)

// ---------------------------------------------------------------------------
//  Root: three-tab pager + floating bottom bar, with category drill-down
// ---------------------------------------------------------------------------

/** Navigation targets for the Settings activity's stack. */
internal sealed interface SettingsNavTarget {
    data object Main : SettingsNavTarget
    data class Category(val name: String) : SettingsNavTarget
    data object License : SettingsNavTarget
    data object Acknowledgements : SettingsNavTarget
    data object HiddenContactsDiagnostics : SettingsNavTarget
    data object ModuleHealth : SettingsNavTarget
}

/**
 * 功能对象（在 Compose 之外）点击后要进子页面时的投递口。
 * 例如「界面美化 → 主题」：ThemeStore.onClick 只能拿到 Activity，拿不到导航栈。
 */
internal object SettingsNavigation {
    val pending = mutableStateOf<SettingsNavTarget?>(null)
}

@Composable
private fun SettingsRoot(onFinish: () -> Unit) {
    val stack = remember { mutableStateListOf<SettingsNavTarget>(SettingsNavTarget.Main) }

    // 接住功能对象的导航请求，避免「点了主题只弹对话框」这种割裂体验。
    val navRequest = SettingsNavigation.pending.value
    LaunchedEffect(navRequest) {
        if (navRequest != null) {
            stack.add(navRequest)
            SettingsNavigation.pending.value = null
        }
    }

    MiuixStackNavigator(stack = stack, onExitRoot = onFinish) { screen, push, pop ->
        when (screen) {
            SettingsNavTarget.Main -> MainPagerScreen(
                onOpenCategory = { push(SettingsNavTarget.Category(it)) },
                onOpenLicense = { push(SettingsNavTarget.License) },
                onOpenAcknowledgements = { push(SettingsNavTarget.Acknowledgements) },
                onOpenModuleHealth = { push(SettingsNavTarget.ModuleHealth) },
            )

            is SettingsNavTarget.Category -> CategoryDetailScreen(
                categoryName = screen.name,
                onBack = pop,
                onOpenHiddenContactsDiagnostics = { push(SettingsNavTarget.HiddenContactsDiagnostics) },
            )

            SettingsNavTarget.License -> LicenseScreen(
                onBack = pop,
            )

            SettingsNavTarget.Acknowledgements -> AcknowledgementsScreen(
                onBack = pop,
            )






            SettingsNavTarget.HiddenContactsDiagnostics -> HiddenContactsDiagnosticsScreen(onBack = pop)

            SettingsNavTarget.ModuleHealth -> ModuleHealthScreen(onBack = pop)
        }
    }
}

@Composable
private fun MainPagerScreen(
    onOpenCategory: (String) -> Unit,
    onOpenLicense: () -> Unit,
    onOpenAcknowledgements: () -> Unit,
    onOpenModuleHealth: () -> Unit,
) {
    val pagerState = rememberPagerState(pageCount = { 4 })
    val isDragged by pagerState.interactionSource.collectIsDraggedAsState()
    val scope = rememberCoroutineScope()
    val backdrop = rememberLayerBackdrop()
    val barBottomPadding = 12.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MiuixTheme.colorScheme.background),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .layerBackdrop(backdrop),
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                key = { it },
            ) { page ->
                when (page) {
                    0 -> HomePager(
                        onOpenFeatures = { scope.launch { pagerState.animateScrollToPage(1) } },
                        onOpenModuleHealth = onOpenModuleHealth,
                    )
                    1 -> FeaturesPager(onOpenCategory = onOpenCategory)
                    2 -> LogsPager()
                    else -> SettingsPager(onOpenLicense = onOpenLicense, onOpenAcknowledgements = onOpenAcknowledgements)
                }
            }
        }

        val haptic = LocalHapticFeedback.current

        FloatingBottomBar(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {},
                )
                .padding(bottom = barBottomPadding),
            selectedIndex = { pagerState.targetPage },
            // Track the pager's fractional scroll 1:1 during a finger swipe; a tab *tap*
            // (programmatic animateScrollToPage, isDragged == false) springs the pill across
            // with the press/glass bulge instead of a flat translate.
            progress = { pagerState.currentPage + pagerState.currentPageOffsetFraction },
            isTracking = { isDragged },
            onSelected = { scope.launch { pagerState.animateScrollToPage(it) } },
            backdrop = backdrop,
            tabsCount = TAB_ITEMS.size,
            isBlurEnabled = true,
            colors = FloatingBottomBarDefaults.colors(
                containerColor = MiuixTheme.colorScheme.surfaceContainer,
                indicatorColor = MiuixTheme.colorScheme.primary,
                contentColor = MiuixTheme.colorScheme.onSurfaceSecondary,
                activeContentColor = MiuixTheme.colorScheme.primary,
            ),
        ) {
            // Key the fill crossfade to targetPage (same driver as the pill), not
            // settledPage — settledPage only updates when animateScrollToPage fully
            // finishes, so the icon would fill a beat after the pill has arrived.
            val target = pagerState.targetPage
            TAB_ITEMS.forEachIndexed { index, item ->
                FloatingBottomBarItem(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.ContextClick)
                        scope.launch { pagerState.animateScrollToPage(index) }
                    },
                    modifier = Modifier.defaultMinSize(minWidth = 76.dp),
                ) {
                    Crossfade(
                        targetState = index == target,
                        animationSpec = tween(200),
                        label = "navIcon",
                    ) { selected ->
                        M3Icon(
                            imageVector = if (selected) item.filled else item.outlined,
                            contentDescription = item.label,
                        )
                    }
                    M3Text(
                        text = item.label,
                        fontSize = 11.sp,
                        lineHeight = 14.sp,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Visible
                    )
                }
            }
        }
    }
}

private data class NavItem(val label: String, val outlined: ImageVector, val filled: ImageVector)

private val TAB_ITEMS = listOf(
    NavItem("主页", MaterialSymbols.Outlined.Home, MaterialSymbols.OutlinedFilled.Home),
    NavItem("功能", MaterialSymbols.Outlined.Tune, MaterialSymbols.OutlinedFilled.Tune),
    NavItem("日志", MaterialSymbols.Outlined.Article, MaterialSymbols.OutlinedFilled.Article),
    NavItem("设置", MaterialSymbols.Outlined.Settings, MaterialSymbols.OutlinedFilled.Settings),
)

/** Bottom padding so scrollable content clears the floating bar. */
val CONTENT_BOTTOM_INSET = 88.dp

// ---------------------------------------------------------------------------
//  Shared scaffold: miuix Scaffold + collapsing TopAppBar + scrollable column
// ---------------------------------------------------------------------------

@Composable
fun MiuixListScaffold(
    title: String,
    navigationIcon: @Composable (() -> Unit)? = null,
    // 关闭后顶栏使用不透明底色、列表不再注册为模糊源，用于规避特定页面（内容为单个超高 item）
    // 在滚动时 backdrop 采样越界导致的顶部灰块。
    blurTopBar: Boolean = true,
    // 内容左右内边距。脚本 Tab 内嵌 Hchat 内容（其 SettingsCard 自带 12dp），此处传 0 避免双重内边距。
    horizontalPadding: Dp = 12.dp,
    content: LazyListScope.() -> Unit,
) {
    val scrollBehavior = MiuixScrollBehavior()
    // The LazyColumn is registered as the blur source; the top bar samples that captured
    // layer through drawBackdrop and paints itself transparent, so scrolled content shows
    // through blurred behind the collapsed bar (InstallerX's useBlur pattern, on miuix-blur glass).
    val barBackdrop = rememberLayerBackdrop()
    val barTint = MiuixTheme.colorScheme.surface.copy(alpha = 0.67f)
    Scaffold(
        topBar = {
            TopAppBar(
                modifier = if (blurTopBar) {
                    Modifier.drawBackdrop(
                        backdrop = barBackdrop,
                        shape = { RectangleShape },
                        effects = {
                            vibrancy()
                            blur(24.dp.toPx(), 24.dp.toPx())
                        },
                        onDrawSurface = { drawRect(barTint) },
                    )
                } else {
                    Modifier
                },
                // Transparent so the miuix bar's own opaque surface doesn't hide the blur.
                color = if (blurTopBar) Color.Transparent else MiuixTheme.colorScheme.surface,
                title = title,
                scrollBehavior = scrollBehavior,
                navigationIcon = { navigationIcon?.invoke() },
            )
        },
        popupHost = {},
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                // 修复「列表页顶部出现异常灰块」：内容超出/回弹时 backdrop 采样会越界绘制。
                .then(if (blurTopBar) Modifier.clipToBounds().layerBackdrop(barBackdrop) else Modifier)
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = horizontalPadding),
            contentPadding = innerPadding,
            overscrollEffect = null,
            content = content,
        )
    }
}

// ---------------------------------------------------------------------------
//  Grouped card: emit each row as its own LazyColumn item so the list stays
//  virtualized, while the per-corner squircle background makes the rows read as
//  one continuous card (round top on the first row, round bottom on the last).
// ---------------------------------------------------------------------------

/**
 * Squircle background matching [Card]'s look but applied per-row, so a long feature list can be
 * emitted as individual `item {}`s (virtualized) instead of one giant `item { Card { forEach } }`
 * that composes every row at once. [index]/[count] pick which corners are rounded.
 */
@Composable
fun Modifier.groupedCardItem(index: Int, count: Int): Modifier {
    val r = CardDefaults.CornerRadius
    val z = 0.dp
    val top = index == 0
    val bottom = index == count - 1
    return fillMaxWidth()
        .squircleSurface(
            color = MiuixTheme.colorScheme.surfaceContainer,
            topStart = if (top) r else z,
            topEnd = if (top) r else z,
            bottomEnd = if (bottom) r else z,
            bottomStart = if (bottom) r else z,
        )
}

// ---------------------------------------------------------------------------
//  Shared feature row (miuix) — used by category detail and search
// ---------------------------------------------------------------------------

@Composable
fun FeatureRow(
    item: BaseFeature,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    val context = LocalComponentActivity.current
    val configKey = item.name

    // API 服务 / 常驻常开功能等无开关项（非 SwitchFeature）：仅展示信息行，不注册开关
    if (item !is SwitchFeature) {
        BasicComponent(onClick = null) {
            Text(
                text = item.displayName,
                fontSize = MiuixTheme.textStyles.headline1.fontSize,
                fontWeight = FontWeight.Medium,
                color = BasicComponentDefaults.titleColor().color,
            )
            Text(
                text = item.description,
                fontSize = MiuixTheme.textStyles.body2.fontSize,
                color = BasicComponentDefaults.summaryColor().color,
            )
        }
        return
    }

    DisposableEffect(configKey) {
        item.setToggleCompletionCallback { onCheckedChange(item.isEnabled) }
        onDispose {}
    }

    fun toggle(requested: Boolean) {
        item as SwitchFeature
        // 当前微信版本已不支持该功能时直接拒绝开启并说明原因，而不是让用户开了发现没反应。
        val unavailable = if (requested) item.unavailableReason else null
        if (unavailable != null) {
            WeLogger.w("SettingsActivity", "拒绝开启 ${item.displayName}：$unavailable")
            showToast(unavailable)
            return
        }
        if (item.onBeforeToggle(requested, context)) {
            WePrefs.putBool(configKey, requested)
            item.isEnabled = requested
            onCheckedChange(requested)
        }
    }

    when (item) {
        is ClickableFeature -> BasicComponent(
            onClick = {
                runCatching { item.onClick(context) }
                    .onFailure { WeLogger.e("SettingsActivity", "onClick failed for ${item.displayName}", it) }
            },
            endActions = {
                if (!item.noSwitchWidget) {
                    Switch(checked = checked, onCheckedChange = { toggle(it) })
                }
            },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.name,
                    fontSize = MiuixTheme.textStyles.headline1.fontSize,
                    fontWeight = FontWeight.Medium,
                    color = BasicComponentDefaults.titleColor().color,
                )
                Spacer(Modifier.width(4.dp))
                Icon(
                    imageVector = MaterialSymbols.Outlined.Settings,
                    contentDescription = "Configurable",
                    modifier = Modifier
                        .padding(end = if (!item.noSwitchWidget) 8.dp else 0.dp)
                        .size(20.dp),
                    tint = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )
            }
            Text(
                text = item.description,
                fontSize = MiuixTheme.textStyles.body2.fontSize,
                color = BasicComponentDefaults.summaryColor().color,
            )
        }

        is SwitchFeature -> SwitchPreference(
            title = item.name,
            summary = item.description,
            checked = checked,
            onCheckedChange = { toggle(it) },
        )
    }
}








