package com.Johnny.wcx.agent.data

import com.Johnny.wcx.agent.data.WeAgentSettings.load
import com.Johnny.wcx.agent.data.entity.SettingEntity
import com.Johnny.wcx.agent.tool.ToolLoadingMode
import com.Johnny.wcx.utils.WeLogger
import java.util.concurrent.ConcurrentHashMap

/**
 * Typed accessor over the `settings` key-value table for WeAgent global configuration (§2.1, §3.3,
 * §5.4, §7, §8). Values are cached in memory after [load]; writes update both the DB and cache.
 * Kept deliberately small — per-feature UI reads/writes go through the named helpers here.
 */
object WeAgentSettings {

    private const val TAG = "WeAgentSettings"
    private val db get() = WeAgentDatabase.instance
    private val cache = ConcurrentHashMap<String, String>()

    // Keys
    const val KEY_MAX_MODEL_REQUESTS = "max_model_requests"          // §2.1 loop cap
    const val KEY_TOOL_LOADING_MODE = "tool_loading_mode"            // §3.3 STATIC | DYNAMIC
    const val KEY_SMALL_MODEL_ID = "small_model_id"                  // §5.4 ("" = same as main)
    const val KEY_WORKSPACE_ENABLED = "workspace_enabled"           // §7
    const val KEY_MEMORY_ENABLED = "memory_enabled"                 // §8
    const val KEY_DEFAULT_MODEL_ID = "default_model_id"             // new-session default
    const val KEY_DEFAULT_SYSTEM_PROMPT_ID = "default_system_prompt_id" // new-session default binding
    const val KEY_DEFAULT_WORKSPACE_ID = "default_workspace_id"     // §7 new-session default
    const val KEY_SEND_WHILE_RUNNING = "send_while_running"         // QUEUE_AFTER_TURN | QUEUE_AS_STEER
    const val KEY_OVERLAY_FOREGROUND_ONLY = "overlay_foreground_only" // hide the floating ball when WeChat is backgrounded

    // Defaults
    const val DEFAULT_MAX_MODEL_REQUESTS = 50

    suspend fun load() {
        runCatching {
            cache.clear()
            db.settingDao().let { dao ->
                // observeAll is a Flow; we just need a one-shot read for warmup.
                dao.getValue(KEY_MAX_MODEL_REQUESTS) // touch to ensure DB is open
            }
        }.onFailure { WeLogger.e(TAG, "load failed", it) }
    }

    private suspend fun get(key: String): String? = cache[key] ?: db.settingDao().getValue(key)?.also { cache[key] = it }

    suspend fun set(key: String, value: String) {
        db.settingDao().upsert(SettingEntity(key, value))
        cache[key] = value
    }

    suspend fun maxModelRequests(): Int =
        get(KEY_MAX_MODEL_REQUESTS)?.toIntOrNull() ?: DEFAULT_MAX_MODEL_REQUESTS

    suspend fun toolLoadingMode(): ToolLoadingMode =
        when (get(KEY_TOOL_LOADING_MODE)) {
            "DYNAMIC" -> ToolLoadingMode.DYNAMIC
            else -> ToolLoadingMode.STATIC
        }

    /** Small model id for smart-approval & title generation; blank means "same as main model" (§5.4). */
    suspend fun smallModelId(): String? = get(KEY_SMALL_MODEL_ID)?.takeIf { it.isNotBlank() }

    suspend fun workspaceEnabled(): Boolean = get(KEY_WORKSPACE_ENABLED)?.toBoolean() ?: false
    suspend fun memoryEnabled(): Boolean = get(KEY_MEMORY_ENABLED)?.toBoolean() ?: false

    suspend fun defaultModelId(): String? = get(KEY_DEFAULT_MODEL_ID)?.takeIf { it.isNotBlank() }
    suspend fun defaultSystemPromptId(): String? = get(KEY_DEFAULT_SYSTEM_PROMPT_ID)?.takeIf { it.isNotBlank() }
    suspend fun defaultWorkspaceId(): String? = get(KEY_DEFAULT_WORKSPACE_ID)?.takeIf { it.isNotBlank() }

    /** When true, the floating ball is only shown while WeChat is in the foreground (default false = always). */
    suspend fun overlayForegroundOnly(): Boolean = get(KEY_OVERLAY_FOREGROUND_ONLY)?.toBoolean() ?: false

    /** Reads the send-while-running mode, defaulting to QUEUE_AFTER_TURN. */
    suspend fun sendWhileRunningMode(): com.Johnny.wcx.features.api.agent.WeAgentService.SendWhileRunningMode =
        when (get(KEY_SEND_WHILE_RUNNING)) {
            "QUEUE_AS_STEER" -> com.Johnny.wcx.features.api.agent.WeAgentService.SendWhileRunningMode.QUEUE_AS_STEER
            else -> com.Johnny.wcx.features.api.agent.WeAgentService.SendWhileRunningMode.QUEUE_AFTER_TURN
        }
}
