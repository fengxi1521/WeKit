package com.Johnny.wcx.features.api.ui

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.BaseAdapter
import android.widget.ListView
import androidx.core.graphics.drawable.toDrawable
import androidx.core.view.isGone
import com.Johnny.wcx.dexkit.abc.IResolveDex
import com.Johnny.wcx.dexkit.dsl.DexMethodDelegate
import com.Johnny.wcx.dexkit.dsl.dexMethod
import com.Johnny.wcx.features.core.ApiFeature
import com.Johnny.wcx.features.core.Feature

import com.Johnny.wcx.ui.utils.findViewByChildIndexes
import com.Johnny.wcx.utils.HookParam
import com.Johnny.wcx.utils.WeLogger
import com.Johnny.wcx.utils.android.runOnUiThread
import java.lang.ref.WeakReference
import java.util.Collections
import java.util.IdentityHashMap
import java.util.WeakHashMap
import java.util.concurrent.CopyOnWriteArrayList

@Feature(
    name = "会话列表 View 绑定监听服务",
    categories = ["API"],
    description = "提供会话列表 View 绑定监听能力"
)
object WeConversationListViewApi : ApiFeature(), IResolveDex {

    data class BindContext(
        val position: Int,
        val itemCount: Int,
        val previousConversation: Any?,
        val nextConversation: Any?,
    )

    fun interface IBindViewListener {
        fun onBind(param: de.robv.android.xposed.XC_MethodHook.MethodHookParam, row: View, conversation: Any, context: BindContext)
    }

    private const val TAG = "WeConversationListViewApi"

    private val listeners = CopyOnWriteArrayList<IBindViewListener>()
    private var latestAdapter: WeakReference<BaseAdapter>? = null
    private var latestListView: WeakReference<ListView>? = null

    private val methodLegacyGetView by dexMethod(allowFailure = true) {
        // 8.0.80 适配：ConversationWithCacheAdapter 的 TAG 已从该 Adapter 移走，且 Adapter 本身
        // 迁到 cp5 包（不在 ui.conversation 下），原 searchPackages 会把它整体过滤掉。
        // 现在靠 getView 日志串（全 APK 唯一）+ 完整签名约束定位，不再限制包名。
        matcher {
            name = "getView"
            paramTypes("int", "android.view.View", "android.view.ViewGroup")
            returnType = "android.view.View"
            usingEqStrings(
                "Get Item duplicated: positionMaps: %s username [%s, %d] Map: %s datas: %d",
            )
        }
    }
    private val methodMvvmGetView by dexMethod {
        matcher {
            declaredClass {
                usingEqStrings(
                    "MicroMsg.ConversationAdapter.MvvmConversationAdapter",
                    "Get Item duplicated: positionMaps: %s username [%s, %d] Map: %s datas: %d",
                )
            }
            name = "getView"
            paramTypes("int", "android.view.View", "android.view.ViewGroup")
            returnType = "android.view.View"
        }
    }

    override fun onEnable() {
        hookBinding(methodLegacyGetView)
        hookBinding(methodMvvmGetView)
    }

    fun addListener(listener: IBindViewListener) {
        if (!listeners.contains(listener)) listeners.add(listener)
    }

    fun removeListener(listener: IBindViewListener) {
        val removed = listeners.remove(listener)
        WeLogger.i(TAG, "listener remove ${if (removed) "succeeded" else "failed"}, current listener count: ${listeners.size}")
    }

    fun refresh() {
        runOnUiThread {
            val adapter = latestAdapter?.get() ?: return@runOnUiThread
            val listView = latestListView?.get()
            if (listView != null && listView.adapter !== adapter) return@runOnUiThread
            dividerCoordinator.applyListView(listView)
            adapter.notifyDataSetChanged()
        }
    }

    fun setDividerHidden(owner: Any, hidden: Boolean) {
        dividerCoordinator.setHidden(owner, hidden)
        refresh()
    }

    fun setRowDividerHidden(owner: Any, row: View, hidden: Boolean) {
        dividerCoordinator.setRowHidden(owner, row, hidden)
        dividerCoordinator.apply(row, latestListView?.get())
    }

    fun removeDividerOwner(owner: Any) {
        dividerCoordinator.removeOwner(owner)
        refresh()
    }

    private fun hookBinding(method: DexMethodDelegate) {
        if (method.isPlaceholder) return
        method.hookAfter {
            // 8.0.77 加固: 异步绑定路径上 result/thisObject 可能为 null, 直接放行避免 NPE 刷日志
            val row = result as? View ?: return@hookAfter
            val adapter = thisObject as? BaseAdapter ?: return@hookAfter
            val position = args[0] as? Int ?: return@hookAfter
            val conversation = adapter.getItem(position) ?: return@hookAfter
            val bindContext = BindContext(
                position = position,
                itemCount = adapter.count,
                previousConversation = if (position > 0) adapter.getItem(position - 1) else null,
                nextConversation = if (position + 1 < adapter.count) adapter.getItem(position + 1) else null,
            )
            if (latestAdapter?.get() !== adapter) latestAdapter = WeakReference(adapter)
            (args[2] as? ListView)?.let { listView ->
                if (latestListView?.get() !== listView) latestListView = WeakReference(listView)
            }

            for (listener in listeners) {
                try {
                    listener.onBind(this, row, conversation, bindContext)
                } catch (error: Exception) {
                    WeLogger.e(TAG, "listener ${listener.javaClass.name} threw", error)
                }
            }
            dividerCoordinator.apply(row, latestListView?.get())
        }
    }

    @Suppress("ClassName")
    private object dividerCoordinator {
        private data class RowDividerState(val originalVisibility: Int)
        private data class ListDividerState(
            val originalDivider: Drawable?,
            val originalDividerHeight: Int,
            val moduleDivider: ColorDrawable,
        )

        private val hiddenOwners = Collections.synchronizedSet(
            Collections.newSetFromMap(IdentityHashMap<Any, Boolean>()),
        )
        private val rowStates = WeakHashMap<View, RowDividerState>()
        private val rowHiddenOwners = WeakHashMap<View, MutableSet<Any>>()
        private val listStates = WeakHashMap<ListView, ListDividerState>()

        fun setHidden(owner: Any, hidden: Boolean) {
            if (hidden) hiddenOwners.add(owner) else hiddenOwners.remove(owner)
        }

        fun setRowHidden(owner: Any, row: View, hidden: Boolean) {
            val owners = rowHiddenOwners[row]
            if (hidden) {
                (owners ?: Collections.newSetFromMap(IdentityHashMap<Any, Boolean>()).also {
                    rowHiddenOwners[row] = it
                }).add(owner)
            } else {
                owners?.remove(owner)
                if (owners != null && owners.isEmpty()) rowHiddenOwners.remove(row)
            }
        }

        fun removeOwner(owner: Any) {
            hiddenOwners.remove(owner)
            val iterator = rowHiddenOwners.entries.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next()
                entry.value.remove(owner)
                if (entry.value.isEmpty()) iterator.remove()
            }
        }

        fun apply(row: View, listView: ListView?) {
            applyRowDivider(row)
            applyListView(listView)
        }

        fun applyListView(listView: ListView?) {
            listView ?: return
            if (hiddenOwners.isNotEmpty()) {
                val state = listStates.getOrPut(listView) {
                    ListDividerState(listView.divider, listView.dividerHeight, Color.TRANSPARENT.toDrawable())
                }
                if (listView.divider !== state.moduleDivider) listView.divider = state.moduleDivider
                if (listView.dividerHeight != 0) listView.dividerHeight = 0
            } else {
                val state = listStates.remove(listView) ?: return
                if (listView.divider === state.moduleDivider) {
                    listView.divider = state.originalDivider
                    listView.dividerHeight = state.originalDividerHeight
                }
            }
        }

        private fun applyRowDivider(row: View) {
            val divider: View = row.findViewByChildIndexes<View>(0, 1, 1, 1)
                ?: row.findViewByChildIndexes<View>(0, 1, 1)
                ?: return
            if (isHidden(row)) {
                rowStates.getOrPut(divider) { RowDividerState(divider.visibility) }
                if (divider.visibility != View.GONE) divider.visibility = View.GONE
            } else {
                val state = rowStates.remove(divider) ?: return
                if (divider.isGone) divider.visibility = state.originalVisibility
            }
        }

        private fun isHidden(row: View): Boolean =
            hiddenOwners.isNotEmpty() || rowHiddenOwners[row]?.isNotEmpty() == true
    }
}
