import java.util.*;

String GAME_KEY = "guess_num_answer";
String GAME_SWITCH = "game_switch";
String ADMIN_SET = "game_admin";
String PLUGIN_NAME = "猜数字小游戏";

void onLoad() {
    Set<String> admins = new HashSet<>(getStringSet(ADMIN_SET, new HashSet<>()));
    String self = getLoginWxid();
    admins.add(self);
    putStringSet(ADMIN_SET, admins);
    log("【成功】猜数字插件已加载｜发送：游戏菜单");
    resetNumber();
}

void onUnload() {
    log("猜数字插件卸载完成");
}

void openSettings() {
    List<String> opt = new ArrayList<>();
    opt.add("开启/关闭游戏");
    opt.add("重置数字答案");
    opt.add("查看管理员");
    opt.add("添加管理员");
    showModuleChoiceDialog(PLUGIN_NAME, "游戏设置", opt, new Consumer() {
        public void accept(Object res) {
            int idx = Integer.parseInt(res.toString());
            Set<String> admins = new HashSet<>(getStringSet(ADMIN_SET, new HashSet<>()));
            String selfWx = getLoginWxid();
            if (!admins.contains(selfWx)) {
                toast("仅管理员可操作");
                return;
            }
            if (idx == 0) {
                boolean open = getBoolean(GAME_SWITCH, true);
                putBoolean(GAME_SWITCH, !open);
                toast(open ? "游戏已关闭" : "游戏已开启");
            } else if (idx == 1) {
                resetNumber();
                toast("新随机数字生成完毕");
            } else if (idx == 2) {
                StringBuilder sb = new StringBuilder("管理员列表：\n");
                for (String wx : admins) sb.append(getFriendName(wx)).append("\n");
                showModuleDialog("管理员", sb.toString());
            } else if (idx == 3) {
                showModuleInputDialog("填写wxid", "", "", new Consumer() {
                    public void accept(Object val) {
                        String wx = val.toString().trim();
                        if (wx.isEmpty()) return;
                        Set<String> list = new HashSet<>(getStringSet(ADMIN_SET, new HashSet<>()));
                        list.add(wx);
                        putStringSet(ADMIN_SET, list);
                        toast("添加管理员成功");
                    }
                });
            }
        }
    });
}

void resetNumber() {
    Random rand = new Random();
    int num = rand.nextInt(100) + 1;
    putInt(GAME_KEY, num);
}

boolean isAdmin(String wxid) {
    Set<String> admins = new HashSet<>(getStringSet(ADMIN_SET, new HashSet<>()));
    return admins.contains(wxid);
}

void onHandleMsg(Object msg) {
    boolean gameOpen = getBoolean(GAME_SWITCH, true);
    String talk = msg.getTalker();
    String sender = msg.getSendTalker();
    String text = msg.getContent().trim();
    // 移除isSelf判断，自己发消息不会被拦截
    log("监听到消息内容：["+text+"] 发送者wxid:"+sender);

    if (!gameOpen) {
        log("游戏总开关已关闭，跳过处理");
        return;
    }

    // 精准匹配游戏菜单
    if (text.equals("游戏菜单")) {
        log("匹配到指令：游戏菜单，正在发送菜单内容");
        String menu = "====猜数字游戏====\n1.猜+数字 例：猜50\n2.重置数字(管理员)\n3.输入@设置打开后台\n数字范围：1~100";
        sendText(talk, menu);
        return;
    }

    if (text.equals("重置数字") && isAdmin(sender)) {
        resetNumber();
        sendText(talk, "✅已刷新新数字，快来猜！");
        return;
    }

    if (text.startsWith("猜")) {
        String numStr = text.substring(1).trim();
        int target = getInt(GAME_KEY, 50);
        int inputNum;
        try {
            inputNum = Integer.parseInt(numStr);
        } catch (Exception e) {
            sendText(talk, "❌格式错误，正确：猜30");
            return;
        }
        if (inputNum < 1 || inputNum > 100) {
            sendText(talk, "❌数字只能1~100");
            return;
        }
        if (inputNum > target) {
            sendText(talk, "[AtWx=" + sender + "] 数字偏大");
        } else if (inputNum < target) {
            sendText(talk, "[AtWx=" + sender + "] 数字偏小");
        } else {
            sendText(talk, "🎉[@" + getFriendName(sender) + "] 猜对！答案：" + target + "，已更换数字");
            resetNumber();
        }
    }
}

boolean onClickSendBtn(String text) {
    if (text.contains("@设置")) {
        openSettings();
        return true;
    }
    return false;
}
