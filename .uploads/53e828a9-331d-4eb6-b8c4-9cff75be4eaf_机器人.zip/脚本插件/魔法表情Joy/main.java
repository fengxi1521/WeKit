// ============================================================
// 入口包装
// ============================================================

evalSnapshot("snapshot_core.java.bshs")

useOnLoad("coreOnLoad")
useOnUnload("coreOnUnload")
useOnHandleMsg("coreOnHandleMsg")
useOnClickSendBtn("coreOnClickSendBtn")

void openSettings() {
    log("授权齿轮入口已进入，开始群校验")
    openCoreSettings()
}
