package dev.ujhhgtg.wekit.constants

import dev.ujhhgtg.wekit.data.KvStore.prefOption

object Preferences {

    const val VERBOSE_LOG = "verbose_log"
    const val NO_DEX_RESOLVE = "no_dex_resolve"
    const val SHOW_STARTUP_TOAST = "toast_startup"
    const val RESET_DEX_ON_HOT_UPDATE = "reset_dex_on_hot_upd"
    const val MATCH_GENERIC_WXID_EXP = "match_generic_wxid"
    const val UI_LANGUAGE = "ui_language"

    // Settings UI theming
    const val THEME_MODE = "settings_theme_mode"
    const val THEME_UI_ENGINE = "settings_theme_ui_engine"
    const val THEME_PREDICTIVE_BACK_ENABLED = "settings_theme_predictive_back_enabled"
    const val THEME_PAGE_TRANSITION_ANIMATION = "settings_theme_page_transition_animation"
    const val THEME_NUKE_HAPTICS = "settings_theme_nuke_haptics"
    const val THEME_NUKE_POPUP_ANIMATION = "settings_theme_nuke_popup_animation"
    const val THEME_NUKE_POPUP_DIALOG_HOST = "settings_theme_nuke_popup_dialog_host"
    const val THEME_NUKE_POPUP_PREDICTIVE_EXIT = "settings_theme_nuke_popup_predictive_exit"
    const val THEME_NUKE_PAGE_EXIT_OPTIMIZATION = "settings_theme_nuke_page_exit_optimization"
    const val THEME_NUKE_IMMEDIATE_PRESS_FEEDBACK = "settings_theme_nuke_immediate_press_feedback"
    const val THEME_DYNAMIC_WALLPAPER = "settings_theme_dynamic_wallpaper"
    const val THEME_PALETTE_STYLE = "settings_theme_palette_style"
    const val THEME_COLOR_SPEC = "settings_theme_color_spec"
    const val THEME_SEED_COLOR = "settings_theme_seed_color"
    const val THEME_APPLY_TO_WECHAT = "settings_theme_apply_to_wechat"

    // Python entry-script editor
    const val PYTHON_EDITOR_SOFT_WRAP = "python_editor_soft_wrap"

    var verboseLog by prefOption(VERBOSE_LOG, false)
    var noDexResolve by prefOption(NO_DEX_RESOLVE, false)
    var showStartupToast by prefOption(SHOW_STARTUP_TOAST, false)
    var resetDexCacheOnHotUpdate by prefOption(RESET_DEX_ON_HOT_UPDATE, false)

    // ALWAYS check whether sender is group chat!!!
    var matchGenericWxIdExp by prefOption(MATCH_GENERIC_WXID_EXP, true)

    // use this when Google fucked up itself again
//    var useActivityInsteadOfDialog: Boolean
//        get() = false
//        set(value) { KvStore.putBool(USE_ACTIVITY_INSTEAD_OF_DIALOG, value) }

    var pythonEditorSoftWrap by prefOption(PYTHON_EDITOR_SOFT_WRAP, false)
}
