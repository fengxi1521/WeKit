package dev.ujhhgtg.wekit.agent.tool

import dev.ujhhgtg.wekit.agent.tool.BuiltinToolProvider.Companion.AVAILABILITY_CHECKS
import dev.ujhhgtg.wekit.agent.tool.BuiltinToolProvider.Companion.exaKeyPresent
import dev.ujhhgtg.wekit.features.core.AgentTool
import kotlinx.serialization.json.JsonObject

/**
 * The built-in tool providers (§3.4), split by the `@AgentTool(group=…)` tag into fixed providers
 * so the settings UI can present them separately:
 *
 *  - `builtin-wechat`      — WeChat operations (send/read/group/moments/…)
 *  - `builtin-wechat-sql`  — raw database SQL (query / execute)
 *  - `builtin-fs`          — Linux environment tools + `load_skill`
 *
 * All are always available and pinned/undeletable in settings. Vision gating is applied per turn by
 * [ToolRegistry] from the turn's [ToolVisibility], so concurrent sessions cannot clobber each other.
 */
class BuiltinToolProvider(
    override val id: String,
    override val name: String,
    private val descriptors: List<AgentToolDescriptor>,
) : ToolProvider {

    override val kind: ProviderKind = ProviderKind.BUILTIN
    override val isAvailable: Boolean = true

    private val byName: Map<String, AgentToolDescriptor> = descriptors.associateBy { it.name }

    /**
     * Every tool this provider owns. Conditional vision gating is
     * NOT applied here — it is per-turn state and is applied by
     * [dev.ujhhgtg.wekit.agent.tool.ToolRegistry.resolveVisibleTools] from the turn's
     * [ToolVisibility]. Doing it here would mean reading process-global flags that concurrent
     * sessions overwrite mid-turn.
     */
    override fun listTools(): List<ProviderTool> =
        descriptors
            .map { d ->
                // If an availability check fires, append its notice to the description so the
                // model can see the constraint before it decides to call the tool.
                val notice = AVAILABILITY_CHECKS[d.name]?.invoke()
                ProviderTool(
                    name = d.name,
                    description = if (notice != null) "${d.description}\n\n⚠ $notice" else d.description,
                    jsonSchema = d.buildJsonSchema(),
                    sideEffect = d.sideEffect,
                )
            }

    override suspend fun execute(toolName: String, arguments: JsonObject): String {
        // Intercept calls to currently-unavailable tools before reaching the invoker,
        // so the model gets the same actionable notice it saw in the description.
        AVAILABILITY_CHECKS[toolName]?.invoke()?.let { return it }
        val descriptor = byName[toolName] ?: return "Unknown builtin tool: $toolName"
        return try {
            descriptor.invoker(AgentToolArgs(arguments))
        } catch (e: AgentToolArgs.AgentToolArgException) {
            "Invalid arguments for '$toolName': ${e.message}"
        } catch (e: Throwable) {
            "Tool '$toolName' failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    companion object {
        const val WECHAT_ID = AgentTool.BUILTIN_WECHAT
        const val WECHAT_SQL_ID = AgentTool.BUILTIN_WECHAT_SQL
        const val FS_ID = AgentTool.BUILTIN_FS
        const val JVM_ID = AgentTool.BUILTIN_JVM
        const val UI_ID = AgentTool.BUILTIN_UI
        const val WEBVIEW_ID = AgentTool.BUILTIN_WEBVIEW
        const val TRIGGER_ID = AgentTool.BUILTIN_TRIGGER
        const val INFO_ID = AgentTool.BUILTIN_INFO
        const val NET_ID = AgentTool.BUILTIN_NET
        const val TERMINAL_ID = AgentTool.BUILTIN_TERMINAL
        val TERMINAL_TOOL_NAMES = setOf("terminal_list", "terminal_start", "terminal_write", "terminal_control", "terminal_read", "terminal_resize", "terminal_kill")

        private val DISPLAY_NAMES = mapOf(
            WECHAT_ID to "微信操作",
            WECHAT_SQL_ID to "数据库 SQL",
            FS_ID to "文件与技能",
            JVM_ID to "JVM 反射",
            UI_ID to "界面工具",
            WEBVIEW_ID to "WebView",
            TRIGGER_ID to "触发器",
            INFO_ID to "环境信息",
            NET_ID to "网络",
        )

        /**
         * Screenshot tool name — advertised only when the turn's model supports vision. Gated
         * per-turn via [ToolVisibility.visionTools]; there is deliberately no global flag for it,
         * because vision support is a property of the model a single turn resolved, and concurrent
         * sessions may resolve different models.
         */
        val VISION_TOOL_NAMES = setOf("ui-screenshot")

        /**
         * Whether an Exa Search API key is configured. Refreshed by WeAgentService whenever the
         * external_services table changes. When false the tool is still visible but its description
         * carries an unavailability notice (see [AVAILABILITY_CHECKS]).
         */
        @Volatile
        var exaKeyPresent: Boolean = false

        /**
         * Whether a Brave Search API key is configured. Same semantics as [exaKeyPresent].
         */
        @Volatile
        var braveKeyPresent: Boolean = false

        /**
         * Per-tool availability checks. Each entry maps a tool name to a lambda that returns:
         *  - `null`   — the tool is fully available; description and execution are unaffected.
         *  - a string — the tool is currently unavailable; the string is appended to the tool
         *               description in [listTools] (so the model discovers the constraint before
         *               calling) **and** returned directly from [execute] if the model calls it
         *               anyway (so it always gets an actionable error, not a cryptic API failure).
         *
         * Extend this map to add new conditional tools (missing permissions, disabled features, …).
         */
        private val AVAILABILITY_CHECKS: Map<String, () -> String?> = mapOf(
            "exa-search" to {
                if (!exaKeyPresent)
                    "此工具当前不可用：用户未配置 Exa Search API Key。" +
                            "请告知用户前往 WeAgent 设置 → 外部服务 中添加 Exa API Key，或请改用其他搜索工具。"
                else null
            },
            "brave-search" to {
                if (!braveKeyPresent)
                    "此工具当前不可用：用户未配置 Brave Search API Key。" +
                            "请告知用户前往 WeAgent 设置 → 外部服务 中添加 Brave Search API Key，或请改用其他搜索工具。"
                else null
            },
        )

        /** All built-in providers, one per `@AgentTool` group present in the generated registry. */
        val all: List<BuiltinToolProvider> by lazy {
            AgentToolsProvider.ALL_TOOLS
                .groupBy { it.group }
                .toSortedMap()
                .map { (group, tools) ->
                    BuiltinToolProvider(
                        id = group,
                        name = DISPLAY_NAMES[group] ?: group,
                        descriptors = tools,
                    )
                }
        }

        /** All built-in provider ids (for the settings list). */
        val allIds: List<String> get() = all.map { it.id }
    }
}
