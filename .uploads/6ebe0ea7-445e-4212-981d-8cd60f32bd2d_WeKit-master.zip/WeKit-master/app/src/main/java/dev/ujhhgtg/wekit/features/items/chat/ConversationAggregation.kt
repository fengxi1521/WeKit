package dev.ujhhgtg.wekit.features.items.chat

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import androidx.activity.ComponentActivity
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.tencent.mm.ui.LauncherUI
import com.tencent.mm.ui.conversation.BaseConversationUI
import com.tencent.mm.ui.conversation.ConvBoxServiceConversationUI
import com.tencent.mm.ui.conversation.MainUI
import dev.ujhhgtg.reflekt.reflekt
import dev.ujhhgtg.reflekt.utils.Modifiers
import dev.ujhhgtg.reflekt.utils.fastJavaMethod
import dev.ujhhgtg.reflekt.utils.isSubclassOf
import dev.ujhhgtg.wekit.R
import dev.ujhhgtg.wekit.dexkit.abc.IResolveDex
import dev.ujhhgtg.wekit.dexkit.dsl.dexMethod
import dev.ujhhgtg.wekit.features.api.core.WeConversationApi
import dev.ujhhgtg.wekit.features.api.core.WeDatabaseApi
import dev.ujhhgtg.wekit.features.api.core.WeDatabaseListenerApi
import dev.ujhhgtg.wekit.features.api.core.models.IWeContact
import dev.ujhhgtg.wekit.features.api.ui.WeStartActivityApi
import dev.ujhhgtg.wekit.features.core.ClickableFeature
import dev.ujhhgtg.wekit.features.core.FeatureCategoryIds
import dev.ujhhgtg.wekit.features.items.chat.ConversationAggregation.syncFoldersToDatabase
import dev.ujhhgtg.wekit.features.items.contacts.CustomLocalFriendAvatars
import dev.ujhhgtg.wekit.i18n.LocalWeKitLocalizedContext
import dev.ujhhgtg.wekit.ui.content.AlertDialogContent
import dev.ujhhgtg.wekit.ui.content.BaseContactSelector
import dev.ujhhgtg.wekit.ui.content.Button
import dev.ujhhgtg.wekit.ui.content.ContactsSelector
import dev.ujhhgtg.wekit.ui.content.DefaultColumn
import dev.ujhhgtg.wekit.ui.content.TextButton
import dev.ujhhgtg.wekit.ui.utils.EditIcon
import dev.ujhhgtg.wekit.ui.utils.showComposeDialog
import dev.ujhhgtg.wekit.utils.HookParam
import dev.ujhhgtg.wekit.utils.HostInfo
import dev.ujhhgtg.wekit.utils.WeLogger
import dev.ujhhgtg.wekit.data.structured.ConversationFolder as ChatFolder
import dev.ujhhgtg.wekit.data.structured.ConversationFolderType as FolderType
import dev.ujhhgtg.wekit.data.JsonDataMigration
import dev.ujhhgtg.wekit.data.WeKitDatabase
import kotlinx.coroutines.runBlocking
import dev.ujhhgtg.wekit.utils.android.showToast
import dev.ujhhgtg.wekit.utils.captureOriginalMethod
import dev.ujhhgtg.wekit.utils.reflection.BString
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.lang.reflect.Proxy
import java.text.Collator
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.io.path.div
import kotlin.io.path.exists
import kotlin.io.path.readText
import kotlin.io.path.writeText
import java.lang.reflect.Modifier as JavaModifier

object ConversationAggregation : ClickableFeature(),
    WeDatabaseListenerApi.IQueryListener,
    WeDatabaseListenerApi.IInsertListener,
    WeDatabaseListenerApi.IUpdateListener,
    WeStartActivityApi.IStartActivityListener,
    IResolveDex {

    override val technicalId = "对话归拢"
    override val nameRes = R.string.feature_conversation_aggregation_name
    override val categoryIds = listOf(FeatureCategoryIds.CHAT)
    override val descriptionRes = R.string.feature_conversation_aggregation_description

    private const val TAG = "AggregateChats"
    const val FOLDER_PREFIX = "wekit_folder_"
    private const val FOLDER_CONFIG_MENU_ID = 0x0721C0DE
    private const val REMOVE_FROM_FOLDER_MENU_ID = 777020

    // Order pushes our item to the end of the container's context menu (its own items use 0).
    private const val REMOVE_FROM_FOLDER_MENU_ORDER = 1000

    // rconversation.flag packing (see WeChat xg3.b.c): high 8 bits = pin / move-up state
    // owned by WeChat (setPlacedTop / unSetPlacedTop), low 56 bits = conversationTime.
    private const val FLAG_TIME_MASK = 0x00FFFFFFFFFFFFFFL
    private const val FLAG_HIGH_MASK = FLAG_TIME_MASK.inv()

    // attrflag bit the conversation box uses to mark "has muted unread" so the homepage
    // badge renders a small dot instead of a number (WeChat w3.b / s2 require this bit set
    // alongside unReadMuteCount > 0 when unReadCount == 0).
    private const val ATTR_FLAG_MUTE_BIT = 2097152


    private const val CONTAINER_UI_NAME = "com.tencent.mm.ui.conversation.ConvBoxServiceConversationUI"
    private val methodConversationStorageQueryByParent by dexMethod(allowFailure = true) {
        matcher {
            usingStrings(
                "select * from rconversation where ",
                " order by flag desc, conversationTime desc"
            )
            paramTypes("int", "java.util.List", "java.lang.String", "int")
            returnType("android.database.Cursor")
        }
    }

    // SelectConversationUI#doClickUser(username) — the single entry point for all conversation
    // taps in the "share to conversation" picker. WeChat only intercepts known virtual usernames
    // ("conversationboxservice", "opencustomerservicemsg") before forwarding to its share logic.
    // Our folder rows (wekit_folder_XXX) pass those guards and reach the share machinery, which
    // tries to open a chat thread for a non-existent contact → crash.
    private val methodSelectConversationDoClickUser by dexMethod(allowFailure = true) {
        matcher {
            usingEqStrings("MicroMsg.SelectConversationUI", "doClickUser=%s")
            paramTypes("java.lang.String")
            returnType("void")
        }
    }

    // The MVVM "select contact" picker (com.tencent.mm.ui.mvvm.MvvmContactListUI) used for in-app
    // forwarding routes every row tap through its list item-click listener cj5.g2#g(View, item, int)
    // (interface in5.u). A tap on a normal conversation dispatches wi5.c0(listOf(username)) to the
    // state center, which sets the "Select_Conv_User" result extra and finishes. Our folder rows
    // (wekit_folder_XXX) reach that same path with a non-existent username → crash downstream.
    // We match the two concrete listeners (main list + search results) by their unique log tags.
    private val methodMvvmMainListItemClick by dexMethod {
        matcher {
            usingStrings("MicroMsg.SelectContactMainRecycleViewUIC", "onItemClickListener data.type")
        }
    }
    private val methodMvvmSearchItemClick by dexMethod {
        matcher {
            usingStrings("MicroMsg.SelectContactSearchMvvmListUIC", "onItemClick: isAlwaysCheck=")
            paramTypes("android.view.View", null, "int")
            returnType("void")
        }
    }

    // com.tencent.mm.storage.m4 (ConversationStorage)#b0(username) — "updateUnreadByTalker".
    // The folder container (ConvBoxServiceConversationUI) sets its superUsername to our folder id
    // (via the Contact_User extra we inject). WeChat's ConvBoxServiceConversationFmUI.onPause()
    // then calls b0(superUsername), which zeroes unReadCount / unReadMuteCount and clears the mute
    // attrflag bit on that exact row — wiping our folder's badge just for opening and leaving the
    // folder without touching any member. We no-op it for folder ids so the aggregate row keeps
    // reflecting its members' (still-unread) state.
    // com.tencent.mm.ui.widget.menu.MMPopupMenu#showMenu(view, pos, id, onCreateListener, selectCb, x, y)
    // The shared long-press popup used by both the homepage list and the folder container. We hook
    // it (gated on activeFolderId) to inject a "remove from folder" item only inside our folders.
    private val methodShowPopupMenu by dexMethod(allowFailure = true) {
        matcher {
            declaredClass {
                usingStrings("MicroMsg.MMPopupMenu")
            }
            paramTypes(
                "android.view.View", "int", "long",
                $$"android.view.View$OnCreateContextMenuListener", null, "int", "int"
            )
            returnType("void")
        }
    }

    @Volatile
    private var activeFolderId: String? = null

    @Volatile
    private var folderSchemaReady: Boolean? = null

    private val storageScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val folderMembersCache = ConcurrentHashMap<String, List<String>>()

    @Volatile
    private var membersByFolder: Map<String, List<String>> = emptyMap()

    @Volatile
    private var folderByMember: Map<String, String> = emptyMap()

    private val suppressQueryRewrite = ThreadLocal.withInitial { false }

    // Reactive refresh: WeChat updates member conversation rows (new message / read state)
    // through the ContentValues insert/update path, but our materialized folder rows are
    // written via raw execSQL and never recomputed until MainUI.onResume. We listen for
    // member-row writes and debounce a lightweight summary recompute so the homepage folder
    // row tracks its members in real time.
    private const val REFRESH_DEBOUNCE_MS = 250L
    private val REFRESH_TASK_TOKEN = Any()
    private val RECONCILE_TASK_TOKEN = Any()
    private const val SQLITE_BIND_CHUNK_SIZE = 900
    private val pendingRefreshMembers = ConcurrentHashMap.newKeySet<String>()
    private val pendingRefreshLock = Any()
    private val refreshAllFolders = AtomicBoolean(false)

    @Volatile
    private var refreshThread: HandlerThread? = null

    @Volatile
    private var refreshHandler: Handler? = null

    override fun onEnable() {
        loadFolders()
        WeDatabaseListenerApi.addListener(this)
        WeStartActivityApi.addListener(this)

        startRefreshThread()

        hookMainUiRefresh()
        hookOpenFolder()
        hookConversationPages()
        hookFolderContextMenu()
        hookSelectConversationUi()
        hookMvvmContactListItemClick()
        hookSqliteWrapperQuery()
        hookConversationStorageParentQuery()
        hookConversationStorageUpdateUnread()

        CustomLocalFriendAvatars.fallbackUsernameProvider = { folderId ->
            if (isFolderId(folderId) && !CustomLocalFriendAvatars.hasCustomAvatar(folderId)) {
                getFallbackAvatarMember(folderId)
            } else {
                null
            }
        }

        // Restore the materialized folder rows when re-enabled at runtime (DB already up), since
        // onDisable released them. On cold startup the DB isn't ready yet and this is a no-op —
        // MainUI.onResume (hookMainUiRefresh) runs the first sync once WeChat is up.
        if (WeDatabaseApi.isReady) {
            syncFoldersToDatabase()
        }
    }

    override fun onDisable() {
        WeDatabaseListenerApi.removeListener(this)
        WeStartActivityApi.removeListener(this)
        CustomLocalFriendAvatars.fallbackUsernameProvider = null
        stopRefreshThread()

        // Release every folder back to the homepage — unmap members and delete all wekit_folder_*
        // rows — so disabling doesn't leave ghost aggregate conversations behind, exactly as if the
        // user had deleted every folder. The saved config is left untouched so onEnable can restore.
        releaseAllFolders()
    }

    /**
     * Reverses [syncFoldersToDatabase]: returns every folder member to the root homepage list and
     * removes all folder rows (rconversation / rcontact / img_flag). Mirrors deleting every folder
     * by hand, but keeps the on-disk config so the folders come back on the next onEnable.
     */
    private fun releaseAllFolders() {
        if (!WeDatabaseApi.isReady) return
        runCatching {
            withQueryRewriteSuppressed {
                if (!isFolderSchemaReady()) return@withQueryRewriteSuppressed
                val folders = loadFolders()
                persistChangedPinFlags(folders, readStoredFolderRows().mapValues { it.value.flag })
                WeDatabaseApi.transaction { clearStaleFolderMappings() }
                membersByFolder = emptyMap()
                folderByMember = emptyMap()
                folderMembersCache.clear()
            }
            WeConversationApi.reloadConversations()
            WeLogger.i(TAG, "released all folders on disable")
        }.onFailure {
            WeLogger.e(TAG, "failed to release folders on disable", it)
        }
    }

    override fun onClick(context: ComponentActivity) {
        if (!JsonDataMigration.isCompleted("chat", "folders")) {
            showToast(context, context.localizedChatString(R.string.structured_storage_unavailable))
            return
        }
        showManagerDialog(context)
    }

    /** Whether [username] is one of our materialized folder rows (vs. a real conversation). */
    fun isAggregationFolderId(username: String): Boolean = isFolderId(username)

    /** A folder choice exposed to other features (e.g. the "add to folder" conversation menu). */
    data class FolderChoice(val id: String, val name: String, val isAuto: Boolean)

    /** Public member snapshot used by contact pickers that need to filter by folder. */
    fun folderMembers(folderId: String): List<String> =
        folderById(folderId)?.let(::getFolderMembers).orEmpty()

    /** Public snapshot of the configured folders, for features that let the user pick one. */
    fun aggregationFolders(): List<FolderChoice> =
        loadFolders().map { FolderChoice(it.id, it.name, it.type != FolderType.MANUAL) }

    /**
     * Adds [talker] to the manual folder [folderId] and opens the existing edit dialog so the
     * user can review and save. Returns false without acting when the folder is missing or in an
     * auto mode (members are computed, not hand-picked); callers surface that to the user.
     */
    fun showAddToFolderDialog(context: Context, folderId: String, talker: String): Boolean {
        val folder = folderById(folderId) ?: return false
        if (folder.type != FolderType.MANUAL) return false
        val updated = folder.copy(members = (folder.members + talker).distinct().sorted())
        showEditFolderDialog(
            context = context,
            folder = updated,
            onFolderUpdated = {
                syncFoldersToDatabase()
            },
            onFolderDeleted = {
                syncFoldersToDatabase()
            }
        )
        return true
    }

    /**
     * Adds [talker] to the manual folder [folderId] and persists immediately (no dialog),
     * rebuilding the index so the row appears in the folder. Returns false without acting when the
     * folder is missing or in an auto mode (members are computed, not hand-picked).
     */
    suspend fun addToFolder(folderId: String, talker: String): Boolean {
        val folder = folderById(folderId) ?: return false
        if (folder.type != FolderType.MANUAL) return false
        if (talker !in folder.members) {
            try {
                WeKitDatabase.instance.conversationCollectionDao().appendFolderMember(folderId, talker)
            } finally {
                invalidateFolders()
            }
            syncFoldersToDatabase()
        }
        return true
    }

    /**
     * Removes [talker] from the manual folder [folderId], persists, and rebuilds the index so the
     * row disappears from the folder immediately. No-op for missing / auto folders, or when the
     * talker isn't actually a member.
     */
    private fun removeMemberFromFolder(folderId: String, talker: String) {
        val folder = folderById(folderId) ?: return
        if (folder.type != FolderType.MANUAL || talker !in folder.members) {
            showToast(localizedChatString(R.string.chat_aggregation_not_in_manual_folder))
            return
        }
        storageScope.launch {
            try {
                try {
                    WeKitDatabase.instance.conversationCollectionDao().removeFolderMember(folderId, talker)
                } finally {
                    invalidateFolders()
                }
                syncFoldersToDatabase()
                showToast(localizedChatString(R.string.chat_aggregation_removed_from_folder, folder.name))
            } catch (error: Exception) {
                if (error is kotlinx.coroutines.CancellationException) throw error
                WeLogger.e(TAG, "Failed to remove folder member", error)
                showToast(localizedChatString(R.string.logs_save_failed))
            }
        }
    }

    // Called by WeDatabaseListenerApi when WeChat inserts a conversation row
    override fun onInsert(table: String, values: ContentValues) {
        if (table != ConversationTable.NAME) return
        val username = values.getAsString(ConversationTable.USERNAME) ?: return
        if (isFolderId(username)) return  // skip our own folder row writes
        scheduleRefresh(username)
    }

    // Called by WeDatabaseListenerApi when WeChat updates conversation rows
    override fun onUpdate(
        table: String,
        values: ContentValues,
        whereClause: String?,
        whereArgs: Array<String>?,
        conflictAlgorithm: Int
    ) {
        if (table != ConversationTable.NAME) return
        // Skip updates that target only folder rows
        val targetUsername = values.getAsString(ConversationTable.USERNAME)
            ?: whereArgs?.singleOrNull()?.takeIf {
                whereClause?.contains(ConversationTable.USERNAME, ignoreCase = true) == true
            }
        if (targetUsername != null && isFolderId(targetUsername)) return
        scheduleRefresh(targetUsername)
    }

    private fun scheduleRefresh(username: String?) {
        val handler = refreshHandler ?: return
        if (loadFolders().isEmpty()) return
        if (username == null) {
            refreshAllFolders.set(true)
        } else {
            synchronized(pendingRefreshLock) { pendingRefreshMembers += username }
        }
        handler.removeCallbacksAndMessages(REFRESH_TASK_TOKEN)
        handler.postAtTime(
            ::doRefreshFolderSummaries,
            REFRESH_TASK_TOKEN,
            SystemClock.uptimeMillis() + REFRESH_DEBOUNCE_MS
        )
    }

    private fun doRefreshFolderSummaries() {
        if (!WeDatabaseApi.isReady) return
        val folders = loadFolders()
        if (folders.isEmpty()) return
        val changedMembers = synchronized(pendingRefreshLock) {
            pendingRefreshMembers.toSet().also { pendingRefreshMembers.clear() }
        }
        val refreshAll = refreshAllFolders.getAndSet(false)

        // A custom SQL rule may depend on any rconversation column. Reconcile it before using the
        // reverse index, because this write may have changed membership rather than just a summary.
        if (folders.any { it.type == FolderType.SQL } ||
            changedMembers.any { it !in folderByMember } && folders.any { it.type != FolderType.MANUAL }
        ) {
            reconcileFolders(folders)
            return
        }

        val affectedFolderIds = if (refreshAll) {
            membersByFolder.keys
        } else {
            changedMembers.mapNotNullTo(linkedSetOf()) { folderByMember[it] }
        }
        if (affectedFolderIds.isEmpty()) return

        runCatching {
            val startedAt = SystemClock.elapsedRealtime()
            withQueryRewriteSuppressed {
                if (!isFolderSchemaReady()) return@withQueryRewriteSuppressed
                val affectedMembers = membersByFolder.filterKeys { it in affectedFolderIds }
                WeDatabaseApi.transaction {
                    affectedMembers.forEach { (folderId, members) ->
                        reanchorFolderMembers(folderId, members)
                    }
                    val summaries = readFolderSummaries(affectedMembers)
                    affectedFolderIds.forEach { folderId ->
                        writeFolderSummaryRow(folderId, summaries[folderId] ?: FolderSummary())
                    }
                }
            }
            WeConversationApi.reloadConversations()
            WeLogger.d(
                TAG,
                "refreshed ${affectedFolderIds.size} folders for ${changedMembers.size} members in " +
                        "${SystemClock.elapsedRealtime() - startedAt}ms"
            )
        }.onFailure {
            WeLogger.e(TAG, "failed to refresh folder summaries", it)
        }
    }

    /**
     * Restores [ConversationTable.PARENT_REF] = [folderId] for any member whose row was
     * replaced by WeChat's own conversation update without a parentRef. Only rows where
     * parentRef is currently NULL or '' are touched — rows already mapped to this folder
     * (or to another folder) are left unchanged.
     */
    private fun reanchorFolderMembers(folderId: String, members: List<String>) {
        if (members.isEmpty()) return
        members.chunked(SQLITE_BIND_CHUNK_SIZE - 1).forEach { chunk ->
            WeDatabaseApi.execStatement(
                """
                UPDATE ${ConversationTable.NAME}
                SET ${ConversationTable.PARENT_REF}=?
                WHERE ${ConversationTable.USERNAME} IN (${placeholders(chunk.size)})
                  AND (${ConversationTable.PARENT_REF} IS NULL OR ${ConversationTable.PARENT_REF}='')
                """.trimIndent(),
                arrayOf(folderId, *chunk.toTypedArray())
            )
        }
    }

    private fun startRefreshThread() {
        val thread = HandlerThread("wekit-folder-refresh").also {
            it.start()
            refreshThread = it
        }
        refreshHandler = Handler(thread.looper)
    }

    private fun stopRefreshThread() {
        refreshHandler?.removeCallbacksAndMessages(null)
        refreshHandler = null
        refreshThread?.quitSafely()
        refreshThread = null
        synchronized(pendingRefreshLock) { pendingRefreshMembers.clear() }
        refreshAllFolders.set(false)
    }

    override fun onQuery(sql: String): String? {
        if (suppressQueryRewrite.get()!!) return null

        val folderId = activeFolderId ?: return null
        return rewriteContainerSql(sql, folderId).takeIf { it != sql }
    }

    override fun onStartActivity(param: HookParam, intent: Intent) {
        val folderId = readFolderIdFromIntent(intent) ?: return
        val componentName = intent.component?.className
        if (componentName != CONTAINER_UI_NAME) {
            activeFolderId = folderId
            intent.setClassName(param.thisObject as? Context ?: return, CONTAINER_UI_NAME)
        }
        applyFolderContainerIntent(intent, folderId)
    }

    private fun hookMainUiRefresh() {
        MainUI::onResume.fastJavaMethod!!.hookAfter {
            syncFoldersToDatabase()
        }
    }

    private fun hookOpenFolder() {
        LauncherUI::startChatting.fastJavaMethod!!.hookBefore {
            interceptFolderChatOpen(args.firstOrNull() as? String, thisObject) {
                result = null
            }
        }

        BaseConversationUI::startChatting.fastJavaMethod!!.hookBefore {
            interceptFolderChatOpen(args.firstOrNull() as? String, thisObject) {
                result = null
            }
        }
    }

    private inline fun interceptFolderChatOpen(
        username: String?,
        source: Any?,
        cancelOriginal: () -> Unit
    ) {
        if (username == null || !isFolderId(username)) return
        activeFolderId = username
        launchFolderContainer(source, username)
        cancelOriginal()
    }

    private fun hookConversationPages() {
        ConvBoxServiceConversationUI::class.hookBeforeOnCreate {
            val activity = thisObject as? Activity ?: return@hookBeforeOnCreate
            activeFolderId = readFolderIdFromIntent(activity.intent) ?: activeFolderId
        }

        BaseConversationUI::class.reflekt().apply {
            firstMethod("onResume").hookAfter {
                val activity = thisObject as? BaseConversationUI ?: return@hookAfter
                activeFolderId = activeFolderId ?: readFolderIdFromIntent(activity.intent)
                configureFolderActivity(activity)
            }

            firstMethod("onDestroy").hookAfter {
                activeFolderId = null
            }
        }
    }

    // The folder container (ConvBoxServiceConversationUI) does NOT use the homepage's
    // ConversationLongClickListener that WeConversationContextMenuApi hooks; it builds its long-press
    // menu through the shared MMPopupMenu.showMenu(...). We hook that chokepoint, gated on
    // activeFolderId (null on the homepage, so that path is untouched), and inject a "remove from
    // folder" item by wrapping the menu-create listener and the (obfuscated) select callback.
    private fun hookFolderContextMenu() {
        if (methodShowPopupMenu.isPlaceholder) return

        // The 5th parameter's declared type is the obfuscated select-callback interface (db5.t4,
        // with the single method onMMMenuItemSelected). We proxy it to intercept our own item.
        val selectCallbackInterface = methodShowPopupMenu.method.parameterTypes[4]

        methodShowPopupMenu.hookBefore {
            val folderId = activeFolderId ?: return@hookBefore
            val folder = folderById(folderId) ?: return@hookBefore
            if (folder.type != FolderType.MANUAL) return@hookBefore

            val createListener = args[3] as? View.OnCreateContextMenuListener ?: return@hookBefore
            val originalSelect = args[4] ?: return@hookBefore
            val position = args[1] as? Int ?: return@hookBefore

            val talker = runCatching { extractFolderTalker(createListener, position) }
                .onFailure { WeLogger.w(TAG, "failed to resolve long-pressed conversation", it) }
                .getOrNull() ?: return@hookBefore

            // Only offer removal on a row that is actually a member of this manual folder.
            if (talker !in folder.members) return@hookBefore

            args[3] = View.OnCreateContextMenuListener { menu, view, menuInfo ->
                createListener.onCreateContextMenu(menu, view, menuInfo)
                runCatching {
                    menu.add(
                        0,
                        REMOVE_FROM_FOLDER_MENU_ID,
                        REMOVE_FROM_FOLDER_MENU_ORDER,
                        localizedChatString(R.string.chat_aggregation_remove_from_folder),
                    )
                }.onFailure { WeLogger.e(TAG, "failed to add folder menu item", it) }
            }

            args[4] = Proxy.newProxyInstance(
                selectCallbackInterface.classLoader,
                arrayOf(selectCallbackInterface)
            ) { _, method, methodArgs ->
                val params = methodArgs ?: emptyArray()
                if (method.name == "onMMMenuItemSelected") {
                    val menuItem = params.getOrNull(0) as? MenuItem
                    if (menuItem?.itemId == REMOVE_FROM_FOLDER_MENU_ID) {
                        runCatching { removeMemberFromFolder(folderId, talker) }
                            .onFailure { WeLogger.e(TAG, "failed to remove from folder", it) }
                        return@newProxyInstance null
                    }
                }
                method.invoke(originalSelect, *params)
            }
        }
    }

    // Intercepts the "share to conversation" picker (SelectConversationUI) before WeChat's share
    // machinery runs. Our folder rows appear in that list because their parentRef is '' (root-level),
    // but they have no real chat thread — forwarding to one crashes. We cancel the call, show a
    // picker scoped to that folder's members, then re-invoke doClickUser with the chosen member so
    // the original share flow proceeds normally.
    private fun hookSelectConversationUi() {
        if (methodSelectConversationDoClickUser.isPlaceholder) return
        methodSelectConversationDoClickUser.hookBefore {
            val username = args.firstOrNull() as? String ?: return@hookBefore
            if (!isFolderId(username)) return@hookBefore

            val folder = folderById(username) ?: return@hookBefore
            val context = thisObject as? Context ?: return@hookBefore
            val originalMethod = captureOriginalMethod()

            // Cancel forwarding to the folder row itself — it has no real chat thread.
            result = null

            showFolderMemberPicker(context, folder) { selectedWxId ->
                runCatching {
                    originalMethod(arrayOf(selectedWxId))
                }.onFailure {
                    WeLogger.e(TAG, "failed to forward share to member $selectedWxId", it)
                }
            }
        }
    }

    // Same folder-row problem as SelectConversationUI, but for the MVVM contact picker
    // (com.tencent.mm.ui.mvvm.MvvmContactListUI) used by in-app forwarding. Every row tap goes
    // through a list item-click listener (cj5.g2#g for the main list, cj5.e4#g for search) whose
    // 2nd arg is the tapped item model (ri5.j). A normal conversation is forwarded by dispatching
    // wi5.c0(listOf(username)); our folder rows reach that path with a non-existent username →
    // crash. We cancel the tap and re-run the ORIGINAL listener with the model's username rewritten
    // to the chosen member so WeChat's own forward flow proceeds.
    private fun hookMvvmContactListItemClick() {
        listOf(
            methodMvvmMainListItemClick,
            methodMvvmSearchItemClick
        ).forEach { method ->
            if (method.isPlaceholder) return@forEach
            method.hookBefore { handleMvvmFolderTap(this) }
        }
    }

    private fun handleMvvmFolderTap(param: HookParam) {
        val itemView = param.args[0] as View
        val data = param.args[1]!!

        val folderField = data.reflekt().fields {
            type = BString
            modifiers(Modifiers.FINAL)
        }[1]
        val folderId = folderField.get()!! as String

        val folder = folderById(folderId) ?: return
        val originalMethod = param.captureOriginalMethod()

        // Cancel the tap on the folder row itself — it has no real chat thread.
        param.result = null

        showFolderMemberPicker(itemView.context, folder) { selectedWxId ->
            runCatching {
                folderField.set(selectedWxId)
                try {
                    // Re-run the ORIGINAL listener (bypasses this hook → no recursion) so WeChat
                    // forwards to the real member exactly as if that row had been tapped.
                    originalMethod()
                } finally {
                    folderField.set(folderId)
                }
            }.onFailure {
                WeLogger.e(TAG, "failed to forward folder tap to member $selectedWxId", it)
            }
        }
    }

    // Shows a picker scoped to a folder's members and invokes onMemberSelected with the chosen
    // member's wxid. Shared by both the SelectConversationUI and MvvmContactListUI interceptions.
    private fun showFolderMemberPicker(
        context: Context,
        folder: ChatFolder,
        onMemberSelected: (String) -> Unit
    ) {
        val members = getFolderMembers(folder).filterNot(::isFolderId).distinct()
        if (members.isEmpty()) {
            showToast(localizedChatString(R.string.chat_aggregation_folder_empty))
            return
        }

        val membersSet = members.toHashSet()
        val contacts = runCatching {
            withQueryRewriteSuppressed {
                WeDatabaseApi.getContacts().filter { it.wxId in membersSet }
            }
        }.getOrDefault(emptyList())

        showComposeDialog(context) {
            FolderShareTargetSelector(
                contacts = contacts,
                onDismiss = onDismiss,
                onSelect = { selectedWxId ->
                    onDismiss()
                    onMemberSelected(selectedWxId)
                }
            )
        }
    }

    // A member picker for the "share to conversation" folder interception. Mirrors the
    // CustomLocalFriendAvatars pattern: no confirm button, each row carries a "选择" trailing
    // button that fires the forward immediately (onItemclick does the same for convenience).
    @Composable
    private fun FolderShareTargetSelector(
        contacts: List<IWeContact>,
        onDismiss: () -> Unit,
        onSelect: (String) -> Unit
    ) {
        var searchQuery by remember { mutableStateOf("") }
        val chinaCollator = remember { Collator.getInstance(Locale.CHINA) }

        val filteredContacts = remember(searchQuery, contacts, chinaCollator) {
            contacts.filter {
                it.displayName.contains(searchQuery, ignoreCase = true) ||
                        it.wxId.contains(searchQuery, ignoreCase = true)
            }.sortedWith(
                compareBy<IWeContact> { it.displayName.isBlank() }
                    .thenComparator { c1, c2 -> chinaCollator.compare(c1.displayName, c2.displayName) }
            )
        }

        BaseContactSelector(
            title = stringResource(R.string.chat_aggregation_select_forward_target),
            searchQuery = searchQuery,
            onSearchQueryChange = { searchQuery = it },
            filteredContacts = filteredContacts,
            confirmButtonText = "",
            confirmButtonEnabled = false,
            showConfirmButton = false,
            dismissButtonText = stringResource(R.string.dialog_cancel),
            onDismiss = onDismiss,
            onConfirm = {},
            selectionKey = Unit,
            isSelected = { false },
            trailingControl = { contact ->
                TextButton(onClick = { onSelect(contact.wxId) }) {
                    Text(stringResource(R.string.chat_aggregation_select))
                }
            },
            onItemClick = { contact -> onSelect(contact.wxId) }
        )
    }

    // Resolves the long-pressed conversation's username from the menu-create listener WeChat passes
    // into MMPopupMenu.showMenu. Chain: createListener -> its OnItemLongClickListener -> the
    // container fragment -> its list adapter -> adapter.getItem(position) (an rconversation row) ->
    // its field_username (kept unobfuscated by WeChat's auto-DB ORM).
    private fun extractFolderTalker(createListener: Any, position: Int): String? {
        val longClickListener = createListener.reflekt()
            .firstFieldOrNull { type { it isSubclassOf AdapterView.OnItemLongClickListener::class } }
            ?.get() ?: return null

        val fragment = longClickListener.reflekt()
            .firstFieldOrNull { type { it.name.endsWith("ConvBoxServiceConversationFmUI") } }
            ?.get() ?: return null

        val adapter = fragment.reflekt()
            .firstFieldOrNull { type { it isSubclassOf android.widget.Adapter::class } }
            ?.get() as? android.widget.Adapter ?: return null

        if (position < 0 || position >= adapter.count) return null
        val conversation = adapter.getItem(position) ?: return null

        return conversation.reflekt()
            .firstFieldOrNull { name = "field_username"; superclass() }
            ?.get() as? String
    }

    private fun hookSqliteWrapperQuery() {
        if (WeDatabaseApi.methodSqliteWrapperRawQuery.isPlaceholder) return
        WeDatabaseApi.methodSqliteWrapperRawQuery.hookBefore {
            if (suppressQueryRewrite.get()!!) return@hookBefore
            val sql = args.firstOrNull() as? String ?: return@hookBefore
            onQuery(sql)?.let { args[0] = it }
        }
    }

    private fun hookConversationStorageParentQuery() {
        if (methodConversationStorageQueryByParent.isPlaceholder) return
        methodConversationStorageQueryByParent.hookBefore {
            val folderId = activeFolderId ?: return@hookBefore
            val parentRef = args.getOrNull(2) as? String ?: return@hookBefore
            if (parentRef == WeChatFolderPlaceholder.CONVERSATION_BOX ||
                parentRef == WeChatFolderPlaceholder.MESSAGE_FOLD
            ) {
                args[2] = folderId
            }
        }
    }

    // See methodConversationStorageUpdateUnreadByTalker: cancel the "mark box read on leave" that
    // WeChat's folder container fires against our folder id, so exiting a folder without opening any
    // member never clears the aggregate row's unread badge.
    private fun hookConversationStorageUpdateUnread() {
        WeConversationApi.methodUpdateUnreadByTalker.hookBefore {
            val username = args.firstOrNull() as? String ?: return@hookBefore
            if (isFolderId(username)) result = true
        }
    }

    private fun launchFolderContainer(source: Any?, folderId: String) {
        val context = source as? Context ?: return
        val intent = Intent().apply {
            setClassName(context, CONTAINER_UI_NAME)
            applyFolderContainerIntent(this, folderId)
        }
        context.startActivity(intent)
    }

    private fun applyFolderContainerIntent(intent: Intent, folderId: String) {
        intent.putExtra(WeChatIntentExtra.CONTACT_USER, folderId)
        intent.putExtra(WeChatIntentExtra.CONTACT_CHAT_ROOM_ID, folderId)
        intent.putExtra(WeChatIntentExtra.ROOM_NAME, folderId)
    }

    private fun configureFolderActivity(activity: BaseConversationUI) {
        val folder = folderById(activeFolderId ?: return) ?: return
        activity.setTitle(folder.name)

        val fragment = activity.conversationFm

        // onResume may fire repeatedly; drop any previous entry before re-adding
        fragment.removeOptionMenu(FOLDER_CONFIG_MENU_ID)

        val listener = MenuItem.OnMenuItemClickListener {
            showEditFolderDialog(
                context = activity,
                folder = folder,
                onFolderUpdated = {
                    syncFoldersToDatabase()
                    configureFolderActivity(activity)
                },
                onFolderDeleted = {
                    syncFoldersToDatabase()
                    activity.finish()
                }
            )
            true
        }

        fragment.addIconOptionMenu(
            FOLDER_CONFIG_MENU_ID,
            localizedChatString(R.string.chat_aggregation_configure),
            EditIcon,
            listener,
        )
    }

    private fun syncFoldersToDatabase() {
        val handler = refreshHandler ?: return
        handler.removeCallbacksAndMessages(RECONCILE_TASK_TOKEN)
        handler.postAtTime(
            { reconcileFolders(loadFolders()) },
            RECONCILE_TASK_TOKEN,
            SystemClock.uptimeMillis()
        )
    }

    private fun reconcileFolders(folders: List<ChatFolder>) {
        if (!WeDatabaseApi.isReady) return
        val startedAt = SystemClock.elapsedRealtime()
        var databaseChanged = false
        runCatching {
            withQueryRewriteSuppressed {
                if (!isFolderSchemaReady()) return@withQueryRewriteSuppressed
                folderMembersCache.clear()
                val desiredMembers = resolveOwnedMembers(folders)
                val desiredOwners = reverseMemberIndex(desiredMembers)
                val currentOwners = readCurrentMemberOwners()
                val storedRows = readStoredFolderRows()
                val liveFlags = storedRows.mapValues { it.value.flag }
                persistChangedPinFlags(folders, liveFlags)

                val desiredFolderIds = folders.mapTo(linkedSetOf()) { it.id }
                val storedFolderIds = readStoredFolderIds()
                val removedFolderIds = storedFolderIds - desiredFolderIds
                val changedOwnerMembers = currentOwners.filter { (member, owner) ->
                    desiredOwners[member] != owner
                }.keys
                val removedMembers = changedOwnerMembers.filterTo(linkedSetOf()) { it !in desiredOwners }
                val changedBindings = desiredOwners.filter { (member, owner) ->
                    currentOwners[member] != owner
                }
                val existingContacts = readFolderContactNames(desiredFolderIds)
                val existingAvatarRows = readExistingAvatarRows(desiredFolderIds)
                val summaries = readFolderSummaries(desiredMembers, storedRows)
                val changedSummaries = folders.mapNotNull { folder ->
                    val summary = summaries[folder.id] ?: FolderSummary()
                    val stored = storedRows[folder.id]
                    if (stored == null ||
                        stored.summary != summary ||
                        stored.attrFlag != summary.attrFlag ||
                        stored.flag and FLAG_TIME_MASK != summary.conversationTime and FLAG_TIME_MASK
                    ) {
                        folder.id to summary
                    } else {
                        null
                    }
                }
                databaseChanged = changedBindings.isNotEmpty() || changedSummaries.isNotEmpty() ||
                        removedMembers.isNotEmpty() || removedFolderIds.isNotEmpty() ||
                        folders.any { it.id !in storedRows || existingContacts[it.id] != it.name } ||
                        desiredFolderIds.any { it !in existingAvatarRows }

                if (databaseChanged) {
                    WeDatabaseApi.transaction {
                        deleteEmptyPlaceholderRows(removedMembers)
                        unbindMembers(removedMembers)
                        ensureManualMemberRows(folders, changedBindings.keys)
                        bindMembers(changedBindings)
                        deleteStoredFolders(removedFolderIds)

                        folders.forEach { folder ->
                            if (folder.id !in storedRows) {
                                ensureFolderConversationRow(folder)
                            }
                            if (existingContacts[folder.id] != folder.name) {
                                writeFolderContact(folder)
                            }
                            if (folder.id !in existingAvatarRows) {
                                writeFolderAvatar(folder.id)
                            }
                        }

                        changedSummaries.forEach { (folderId, summary) ->
                            writeFolderSummaryRow(folderId, summary)
                        }
                    }
                }

                membersByFolder = desiredMembers
                folderByMember = desiredOwners
                desiredMembers.forEach { (folderId, members) ->
                    folderMembersCache[folderId] = members
                }

                WeLogger.i(
                    TAG,
                    "reconciled ${folders.size} folders: bindings=${changedBindings.size}, " +
                    "unbound=${removedMembers.size}, removed=${removedFolderIds.size}, " +
                            "elapsed=${SystemClock.elapsedRealtime() - startedAt}ms"
                )
            }
            if (databaseChanged) WeConversationApi.reloadConversations()
        }.onFailure {
            WeLogger.e(TAG, "failed to sync folders", it)
        }
    }

    private fun resolveOwnedMembers(folders: List<ChatFolder>): Map<String, List<String>> {
        val candidates = linkedMapOf<String, List<String>>()
        val ownerByMember = linkedMapOf<String, String>()
        folders.forEach { folder ->
            val members = resolveFolderMembers(folder).filterNot(::isFolderId).distinct()
            candidates[folder.id] = members
            members.forEach { ownerByMember[it] = folder.id }
        }
        return candidates.mapValues { (folderId, members) ->
            members.filter { ownerByMember[it] == folderId }
        }
    }

    private fun reverseMemberIndex(byFolder: Map<String, List<String>>): Map<String, String> =
        buildMap { byFolder.forEach { (folderId, members) -> members.forEach { put(it, folderId) } } }

    private fun readCurrentMemberOwners(): Map<String, String> {
        val result = linkedMapOf<String, String>()
        WeDatabaseApi.rawQuery(
            "SELECT ${ConversationTable.USERNAME}, ${ConversationTable.PARENT_REF} " +
                    "FROM ${ConversationTable.NAME} WHERE ${ConversationTable.PARENT_REF} LIKE ?",
            arrayOf("$FOLDER_PREFIX%")
        ).use { cursor ->
            while (cursor.moveToNext()) result[cursor.getString(0)] = cursor.getString(1)
        }
        return result
    }

    private fun readStoredFolderRows(): Map<String, StoredFolderRow> {
        val result = linkedMapOf<String, StoredFolderRow>()
        WeDatabaseApi.rawQuery(
            """
            SELECT ${ConversationTable.USERNAME}, ${ConversationTable.FLAG}, ${ConversationTable.DIGEST},
                   ${ConversationTable.DIGEST_USER}, ${ConversationTable.IS_SEND}, ${ConversationTable.STATUS},
                   ${ConversationTable.CONVERSATION_TIME}, ${ConversationTable.UNREAD_COUNT},
                   ${ConversationTable.UNREAD_MUTE_COUNT}, ${ConversationTable.CONTENT},
                   ${ConversationTable.MSG_TYPE}, ${ConversationTable.CHAT_MODE}, ${ConversationTable.ATTR_FLAG}
            """.trimIndent() + " " +
                    "FROM ${ConversationTable.NAME} WHERE ${ConversationTable.USERNAME} LIKE ?",
            arrayOf("$FOLDER_PREFIX%")
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result[cursor.getString(0)] = StoredFolderRow(
                    flag = cursor.getLongOrZero(ConversationTable.FLAG),
                    attrFlag = cursor.getIntOrZero(ConversationTable.ATTR_FLAG),
                    summary = FolderSummary(
                        digest = cursor.getStringOrEmpty(ConversationTable.DIGEST),
                        digestUser = cursor.getStringOrEmpty(ConversationTable.DIGEST_USER),
                        isSend = cursor.getIntOrZero(ConversationTable.IS_SEND),
                        status = cursor.getIntOrZero(ConversationTable.STATUS),
                        conversationTime = cursor.getLongOrZero(ConversationTable.CONVERSATION_TIME),
                        unreadCount = cursor.getIntOrZero(ConversationTable.UNREAD_COUNT),
                        unreadMuteCount = cursor.getIntOrZero(ConversationTable.UNREAD_MUTE_COUNT),
                        content = cursor.getStringOrEmpty(ConversationTable.CONTENT),
                        msgType = cursor.getStringOrEmpty(ConversationTable.MSG_TYPE),
                        chatMode = cursor.getIntOrZero(ConversationTable.CHAT_MODE)
                    )
                )
            }
        }
        return result
    }

    private fun readStoredFolderIds(): Set<String> {
        val result = linkedSetOf<String>()
        listOf(ConversationTable.NAME, ContactTable.NAME, "img_flag").forEach { table ->
            WeDatabaseApi.rawQuery(
                "SELECT username FROM $table WHERE username LIKE ?",
                arrayOf("$FOLDER_PREFIX%")
            ).use { cursor -> while (cursor.moveToNext()) result += cursor.getString(0) }
        }
        return result
    }

    private fun readFolderContactNames(folderIds: Set<String>): Map<String, String> {
        if (folderIds.isEmpty()) return emptyMap()
        val result = linkedMapOf<String, String>()
        folderIds.chunked(SQLITE_BIND_CHUNK_SIZE).forEach { ids ->
            WeDatabaseApi.rawQuery(
                "SELECT ${ContactTable.USERNAME}, ${ContactTable.NICKNAME} FROM ${ContactTable.NAME} " +
                        "WHERE ${ContactTable.USERNAME} IN (${placeholders(ids.size)})",
                ids.toTypedArray()
            ).use { cursor ->
                while (cursor.moveToNext()) result[cursor.getString(0)] = cursor.getString(1) ?: ""
            }
        }
        return result
    }

    private fun readExistingAvatarRows(folderIds: Set<String>): Set<String> {
        if (folderIds.isEmpty()) return emptySet()
        val result = linkedSetOf<String>()
        folderIds.chunked(SQLITE_BIND_CHUNK_SIZE).forEach { ids ->
            WeDatabaseApi.rawQuery(
                "SELECT username FROM img_flag WHERE username IN (${placeholders(ids.size)})",
                ids.toTypedArray()
            ).use { cursor -> while (cursor.moveToNext()) result += cursor.getString(0) }
        }
        return result
    }

    private fun persistChangedPinFlags(folders: List<ChatFolder>, liveFlags: Map<String, Long>) {
        val changed = folders.mapNotNull { folder ->
            val liveHigh = liveFlags[folder.id]?.and(FLAG_HIGH_MASK)
            if (liveHigh == null || liveHigh == folder.pinFlag) null else folder.id to liveHigh
        }.toMap()
        if (changed.isEmpty()) return
        storageScope.launch {
            try {
                try {
                    WeKitDatabase.instance.conversationCollectionDao().putFolderPinFlags(changed)
                } finally {
                    invalidateFolders()
                }
            } catch (error: Exception) {
                if (error is kotlinx.coroutines.CancellationException) throw error
                WeLogger.e(TAG, "Failed to persist folder pin flags", error)
                showToast(localizedChatString(R.string.logs_save_failed))
            }
        }
    }

    private fun clearStaleFolderMappings() {
        listOf(FOLDER_PREFIX).forEach { prefix ->
            WeDatabaseApi.execStatement(
                """
                DELETE FROM ${ConversationTable.NAME}
                WHERE ${ConversationTable.PARENT_REF} LIKE ?
                  AND ${ConversationTable.DIGEST}=''
                  AND ${ConversationTable.CONTENT}=''
                  AND ${ConversationTable.UNREAD_COUNT}=0
                  AND ${ConversationTable.CONVERSATION_TIME}=0
                  AND ${ConversationTable.FLAG}=0
                  AND ${ConversationTable.MSG_TYPE}=''
                  AND ${ConversationTable.STATUS}=0
                  AND ${ConversationTable.IS_SEND}=0
                """.trimIndent(),
                arrayOf("$prefix%")
            )
            WeDatabaseApi.execStatement(
                "UPDATE ${ConversationTable.NAME} SET ${ConversationTable.PARENT_REF}='' WHERE ${ConversationTable.PARENT_REF} LIKE ?",
                arrayOf("$prefix%")
            )
            WeDatabaseApi.execStatement(
                "DELETE FROM ${ConversationTable.NAME} WHERE ${ConversationTable.USERNAME} LIKE ?",
                arrayOf("$prefix%")
            )
            WeDatabaseApi.execStatement(
                "DELETE FROM ${ContactTable.NAME} WHERE ${ContactTable.USERNAME} LIKE ?",
                arrayOf("$prefix%")
            )
            WeDatabaseApi.execStatement(
                "DELETE FROM img_flag WHERE username LIKE ?",
                arrayOf("$prefix%")
            )
        }
    }

    private fun placeholders(count: Int): String = List(count) { "?" }.joinToString(",")

    private fun deleteEmptyPlaceholderRows(members: Collection<String>) {
        members.chunked(SQLITE_BIND_CHUNK_SIZE).forEach { chunk ->
            WeDatabaseApi.execStatement(
                """
                DELETE FROM ${ConversationTable.NAME}
                WHERE ${ConversationTable.USERNAME} IN (${placeholders(chunk.size)})
                  AND ${ConversationTable.PARENT_REF} LIKE ?
                  AND ${ConversationTable.DIGEST}='' AND ${ConversationTable.CONTENT}=''
                  AND ${ConversationTable.UNREAD_COUNT}=0 AND ${ConversationTable.CONVERSATION_TIME}=0
                  AND ${ConversationTable.FLAG}=0 AND ${ConversationTable.MSG_TYPE}=''
                  AND ${ConversationTable.STATUS}=0 AND ${ConversationTable.IS_SEND}=0
                """.trimIndent(),
                arrayOf(*chunk.toTypedArray(), "$FOLDER_PREFIX%")
            )
        }
    }

    private fun unbindMembers(members: Collection<String>) {
        members.chunked(SQLITE_BIND_CHUNK_SIZE).forEach { chunk ->
            WeDatabaseApi.execStatement(
                "UPDATE ${ConversationTable.NAME} SET ${ConversationTable.PARENT_REF}='' " +
                        "WHERE ${ConversationTable.USERNAME} IN (${placeholders(chunk.size)}) " +
                        "AND ${ConversationTable.PARENT_REF} LIKE ?",
                arrayOf(*chunk.toTypedArray(), "$FOLDER_PREFIX%")
            )
        }
    }

    private fun ensureManualMemberRows(folders: List<ChatFolder>, changedMembers: Collection<String>) {
        val changed = changedMembers.toHashSet()
        folders.filter { it.type == FolderType.MANUAL }.forEach { folder ->
            folder.members.asSequence()
                .filter { it in changed && !isFolderId(it) }
                .distinct()
                .chunked(SQLITE_BIND_CHUNK_SIZE / 2)
                .forEach { chunk ->
                    val values = chunk.joinToString(",") { "(?, ?, '', '', 0, 0, 0, 0, 0, 0, '', '', 0)" }
                    val args: Array<Any> = chunk.flatMap { listOf<Any>(it, folder.id) }.toTypedArray()
                    WeDatabaseApi.execStatement(
                        """
                        INSERT OR IGNORE INTO ${ConversationTable.NAME} (
                            ${ConversationTable.USERNAME}, ${ConversationTable.PARENT_REF}, ${ConversationTable.DIGEST},
                            ${ConversationTable.DIGEST_USER}, ${ConversationTable.IS_SEND}, ${ConversationTable.STATUS},
                            ${ConversationTable.CONVERSATION_TIME}, ${ConversationTable.FLAG}, ${ConversationTable.UNREAD_COUNT},
                            ${ConversationTable.UNREAD_MUTE_COUNT}, ${ConversationTable.CONTENT},
                            ${ConversationTable.MSG_TYPE}, ${ConversationTable.CHAT_MODE}
                        ) VALUES $values
                        """.trimIndent(),
                        args
                    )
                }
        }
    }

    private fun bindMembers(bindings: Map<String, String>) {
        bindings.entries.groupBy({ it.value }, { it.key }).forEach { (folderId, members) ->
            members.chunked(SQLITE_BIND_CHUNK_SIZE - 1).forEach { chunk ->
                WeDatabaseApi.execStatement(
                    "UPDATE ${ConversationTable.NAME} SET ${ConversationTable.PARENT_REF}=? " +
                            "WHERE ${ConversationTable.USERNAME} IN (${placeholders(chunk.size)})",
                    arrayOf(folderId, *chunk.toTypedArray())
                )
            }
        }
    }

    private fun deleteStoredFolders(folderIds: Set<String>) {
        folderIds.chunked(SQLITE_BIND_CHUNK_SIZE).forEach { chunk ->
            val where = "username IN (${placeholders(chunk.size)})"
            listOf(ConversationTable.NAME, ContactTable.NAME, "img_flag").forEach { table ->
                WeDatabaseApi.execStatement("DELETE FROM $table WHERE $where", chunk.toTypedArray())
            }
        }
    }

    private fun ensureFolderConversationRow(folder: ChatFolder) {
        WeDatabaseApi.execStatement(
            """
            INSERT OR IGNORE INTO ${ConversationTable.NAME} (
                ${ConversationTable.USERNAME}, ${ConversationTable.PARENT_REF}, ${ConversationTable.FLAG},
                ${ConversationTable.CONVERSATION_TIME}, ${ConversationTable.DIGEST}, ${ConversationTable.CONTENT}
            ) VALUES (?, '', ?, 0, '', '')
            """.trimIndent(),
            arrayOf(folder.id, folder.pinFlag and FLAG_HIGH_MASK)
        )
    }

    private fun writeFolderContact(folder: ChatFolder) {
        WeDatabaseApi.execStatement(
            """
            REPLACE INTO ${ContactTable.NAME} (
                ${ContactTable.USERNAME}, ${ContactTable.NICKNAME}, ${ContactTable.TYPE}, ${ContactTable.VERIFY_FLAG}
            ) VALUES (?, ?, 3, 0)
            """.trimIndent(),
            arrayOf(folder.id, folder.name)
        )
    }

    private fun writeFolderAvatar(folderId: String) {
        WeDatabaseApi.execStatement(
            """
            INSERT OR IGNORE INTO img_flag (username, imgflag, lastupdatetime, reserved1, reserved2)
            VALUES (?, 3, ?, 0, ?)
            """.trimIndent(),
            arrayOf(folderId, System.currentTimeMillis() / 1000, "http://wekit.local/avatar/$folderId")
        )
    }

    /** Updates a materialized folder row while preserving WeChat's live pin bits. */
    private fun writeFolderSummaryRow(folderId: String, summary: FolderSummary) {
        WeDatabaseApi.execStatement(
            """
            UPDATE ${ConversationTable.NAME} SET
                ${ConversationTable.DIGEST}=?, ${ConversationTable.DIGEST_USER}=?,
                ${ConversationTable.IS_SEND}=?, ${ConversationTable.STATUS}=?,
                ${ConversationTable.CONVERSATION_TIME}=?,
                ${ConversationTable.FLAG}=(${ConversationTable.FLAG} & ?) | ?,
                ${ConversationTable.UNREAD_COUNT}=?, ${ConversationTable.UNREAD_MUTE_COUNT}=?,
                ${ConversationTable.CONTENT}=?, ${ConversationTable.MSG_TYPE}=?,
                ${ConversationTable.CHAT_MODE}=?, ${ConversationTable.ATTR_FLAG}=?
            WHERE ${ConversationTable.USERNAME}=?
            """.trimIndent(),
            arrayOf(
                summary.digest,
                summary.digestUser,
                summary.isSend,
                summary.status,
                summary.conversationTime,
                FLAG_HIGH_MASK,
                summary.conversationTime and FLAG_TIME_MASK,
                summary.unreadCount,
                summary.unreadMuteCount,
                summary.content,
                summary.msgType,
                summary.chatMode,
                summary.attrFlag,
                folderId
            )
        )
    }

    private fun readFolderSummaries(
        byFolder: Map<String, List<String>>,
        storedRows: Map<String, StoredFolderRow> = emptyMap()
    ): Map<String, FolderSummary> {
        val ownerByMember = reverseMemberIndex(byFolder)
        val states = byFolder.mapValuesTo(linkedMapOf()) { SummaryAccumulator() }
        val members = ownerByMember.keys.toList()

        members.chunked(SQLITE_BIND_CHUNK_SIZE).forEach { chunk ->
            WeDatabaseApi.rawQuery(
                """
                SELECT r.${ConversationTable.USERNAME}, r.${ConversationTable.DIGEST},
                       r.${ConversationTable.DIGEST_USER}, r.${ConversationTable.IS_SEND},
                       r.${ConversationTable.STATUS}, r.${ConversationTable.CONVERSATION_TIME},
                       r.${ConversationTable.UNREAD_COUNT}, r.${ConversationTable.CONTENT},
                       r.${ConversationTable.MSG_TYPE}, r.${ConversationTable.CHAT_MODE},
                       c.${ContactTable.TYPE}, c.${ContactTable.LV_BUFF},
                       c.${ContactTable.CON_REMARK}, c.${ContactTable.NICKNAME}
                FROM ${ConversationTable.NAME} r
                LEFT JOIN ${ContactTable.NAME} c
                  ON c.${ContactTable.USERNAME}=r.${ConversationTable.USERNAME}
                WHERE r.${ConversationTable.USERNAME} IN (${placeholders(chunk.size)})
                """.trimIndent(),
                chunk.toTypedArray()
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    val username = cursor.getStringOrEmpty(ConversationTable.USERNAME)
                    val folderId = ownerByMember[username] ?: continue
                    val state = states.getValue(folderId)
                    val unread = cursor.getIntOrZero(ConversationTable.UNREAD_COUNT).coerceAtLeast(0)
                    if (unread > 0) {
                        val muted = if (username.endsWith("@chatroom")) {
                            val index = cursor.getColumnIndex(ContactTable.LV_BUFF)
                            val lvBuff = if (index >= 0 && !cursor.isNull(index)) cursor.getBlob(index) else null
                            WeConversationApi.parseChatRoomNotify(lvBuff) == 0
                        } else {
                            cursor.getIntOrZero(ContactTable.TYPE) and 512 != 0
                        }
                        if (muted) state.mutedUnread += unread else state.normalUnread += unread
                    }

                    val time = cursor.getLongOrZero(ConversationTable.CONVERSATION_TIME)
                    if (state.latest == null || time > state.latest!!.conversationTime) {
                        val nickname = cursor.getStringOrEmpty(ContactTable.NICKNAME)
                        val remark = cursor.getStringOrEmpty(ContactTable.CON_REMARK)
                        val displayName = if (username.endsWith("@chatroom")) nickname else remark.ifBlank { nickname }
                        state.latest = MemberSummaryRow(
                            digest = prefixWithConversationName(
                                displayName.takeIf { it.isNotBlank() && it != username },
                                cursor.getStringOrEmpty(ConversationTable.DIGEST)
                            ),
                            digestUser = cursor.getStringOrEmpty(ConversationTable.DIGEST_USER),
                            isSend = cursor.getIntOrZero(ConversationTable.IS_SEND),
                            status = cursor.getIntOrZero(ConversationTable.STATUS),
                            conversationTime = time,
                            content = cursor.getStringOrEmpty(ConversationTable.CONTENT),
                            msgType = cursor.getStringOrEmpty(ConversationTable.MSG_TYPE),
                            chatMode = cursor.getIntOrZero(ConversationTable.CHAT_MODE)
                        )
                    }
                }
            }
        }

        return states.mapValues { (folderId, state) ->
            val latest = state.latest
            if (latest == null) {
                FolderSummary(
                    conversationTime = storedRows[folderId]?.summary?.conversationTime
                        ?: System.currentTimeMillis()
                )
            } else {
                FolderSummary(
                    digest = latest.digest,
                    digestUser = latest.digestUser,
                    isSend = latest.isSend,
                    status = latest.status,
                    conversationTime = latest.conversationTime.takeIf { it > 0L }
                        ?: storedRows[folderId]?.summary?.conversationTime
                        ?: System.currentTimeMillis(),
                    unreadCount = state.normalUnread,
                    unreadMuteCount = state.mutedUnread,
                    content = latest.content,
                    msgType = latest.msgType,
                    chatMode = latest.chatMode
                )
            }
        }
    }

    /**
     * Prefixes the folder digest with the originating conversation's display name, so the
     * homepage folder row reads like "群聊名: 最新一条消息" instead of a bare message whose
     * source is ambiguous once several chats are aggregated. Returns the digest untouched
     * when it is blank or the name can't be resolved, to avoid a dangling "name: " prefix.
     */
    private fun prefixWithConversationName(displayName: String?, digest: String): String {
        if (digest.isBlank() || displayName.isNullOrBlank()) return digest
        return "$displayName: $digest"
    }

    private fun isFolderSchemaReady(): Boolean {
        folderSchemaReady?.let { return it }
        val result = runCatching {
            val conversationColumns = tableColumns(ConversationTable.NAME)
            val contactColumns = tableColumns(ContactTable.NAME)
            val missingConversationColumns = ConversationTable.REQUIRED_COLUMNS - conversationColumns
            val missingContactColumns = ContactTable.REQUIRED_COLUMNS - contactColumns
            if (missingConversationColumns.isNotEmpty() || missingContactColumns.isNotEmpty()) {
                WeLogger.w(
                    TAG,
                    "skip folders sync, schema mismatch: " +
                            "rconversation missing=${missingConversationColumns.joinToString()}, " +
                            "rcontact missing=${missingContactColumns.joinToString()}"
                )
                false
            } else {
                true
            }
        }.onFailure {
            WeLogger.w(TAG, "skip folders sync, failed to inspect WeChat database schema", it)
        }.getOrNull()
        // Only latch the outcome when the check actually completed. A transient failure (the
        // database being briefly locked or closing right after WeDatabaseApi.isReady flips)
        // must not permanently disable folder sync for the rest of the process — leave the
        // cached value unset so the next call retries.
        if (result != null) {
            folderSchemaReady = result
        }
        return result == true
    }

    private fun tableColumns(table: String): Set<String> {
        val columns = linkedSetOf<String>()
        val cursor = WeDatabaseApi.rawQuery("PRAGMA table_info($table)")
        cursor.use { cursor ->
            val nameIndex = cursor.getColumnIndex("name")
            while (cursor.moveToNext()) {
                columns += cursor.getString(nameIndex)
            }
        }
        return columns
    }

    private fun rewriteContainerSql(sql: String, folderId: String): String {
        if (!sql.contains(ConversationTable.NAME, ignoreCase = true) ||
            !sql.contains(ConversationTable.PARENT_REF, ignoreCase = true)
        ) {
            return sql
        }
        if (!sql.contains(WeChatFolderPlaceholder.CONVERSATION_BOX) && !sql.contains(WeChatFolderPlaceholder.MESSAGE_FOLD)) {
            return sql
        }
        return sql
            .replace(WeChatFolderPlaceholder.CONVERSATION_BOX, folderId)
            .replace(WeChatFolderPlaceholder.MESSAGE_FOLD, folderId)
    }

    private fun readFolderIdFromIntent(intent: Intent?): String? {
        if (intent == null) return null
        return WeChatIntentExtra.ALL
            .asSequence()
            .mapNotNull { intent.getStringExtra(it) }
            .firstOrNull(::isFolderId)
    }

    private inline fun <T> withQueryRewriteSuppressed(action: () -> T): T {
        val oldValue = suppressQueryRewrite.get()
        suppressQueryRewrite.set(true)
        return try {
            action()
        } finally {
            suppressQueryRewrite.set(oldValue)
        }
    }

    private fun showManagerDialog(context: Context) {
        showComposeDialog(context) {
            var folders by remember { mutableStateOf(loadFolders()) }

            AlertDialogContent(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(),
                title = { Text(stringResource(R.string.chat_aggregation_title)) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        LazyColumn(
                            modifier = Modifier.heightIn(max = 420.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (folders.isEmpty()) {
                                item {
                                    Text(stringResource(R.string.chat_aggregation_no_folders))
                                }
                            }
                            items(folders, key = { it.id }) { folder ->
                                FolderRow(folder) {
                                    showEditFolderDialog(
                                        context = context,
                                        folder = folder,
                                        onFolderUpdated = { folders = loadFolders() },
                                        onFolderDeleted = { folders = loadFolders() }
                                    )
                                }
                            }
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        syncFoldersToDatabase()
                        showToast(localizedChatString(R.string.chat_aggregation_index_rebuilt))
                    }) { Text(stringResource(R.string.chat_aggregation_reload)) }
                    TextButton(onClick = {
                        showCreateFolderDialog(context) {
                            folders = loadFolders()
                        }
                    }) { Text(stringResource(R.string.chat_aggregation_create)) }
                },
                confirmButton = {
                    Button(onClick = {
                        onDismiss()
                    }) { Text(stringResource(R.string.dialog_close)) }
                }
            )
        }
    }

    private fun showCreateFolderDialog(context: Context, onFolderCreated: () -> Unit) {
        showComposeDialog(context) {
            FolderEditorDialog(
                title = stringResource(R.string.chat_aggregation_create_folder),
                folder = null,
                onDismiss = onDismiss,
                onSavingChanged = { dialog.setCancelable(!it) },
                onSave = { folder ->
                    upsertFolder(folder)
                    onFolderCreated()
                    onDismiss()
                }
            )
        }
    }

    private fun showEditFolderDialog(
        context: Context,
        folder: ChatFolder,
        onFolderUpdated: () -> Unit,
        onFolderDeleted: () -> Unit
    ) {
        showComposeDialog(context) {
            FolderEditorDialog(
                title = stringResource(R.string.chat_aggregation_edit_folder),
                folder = folder,
                onDismiss = onDismiss,
                onDelete = {
                    deleteFolder(folder.id)
                    onFolderDeleted()
                    onDismiss()
                },
                onSavingChanged = { dialog.setCancelable(!it) },
                onSave = { updatedFolder ->
                    upsertFolder(updatedFolder)
                    onFolderUpdated()
                    onDismiss()
                }
            )
        }
    }

    @Composable
    private fun folderTypeLabel(type: FolderType): String = when (type) {
        FolderType.MANUAL -> stringResource(R.string.chat_aggregation_mode_manual)
        FolderType.PRESET_GROUPS -> stringResource(R.string.chat_aggregation_mode_all_groups)
        FolderType.PRESET_OFFICIALS -> stringResource(R.string.chat_aggregation_mode_all_officials)
        FolderType.SQL -> stringResource(R.string.chat_aggregation_mode_sql)
    }

    @Composable
    private fun FolderRow(folder: ChatFolder, onClick: () -> Unit) {
        val count = remember(folder) { getFolderMembers(folder).size }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(vertical = 8.dp)
        ) {
            Text(folder.name)
            val desc = when (folder.type) {
                FolderType.MANUAL -> pluralStringResource(
                    R.plurals.chat_aggregation_manual_conversation_count,
                    count,
                    count,
                )
                FolderType.PRESET_GROUPS -> pluralStringResource(
                    R.plurals.chat_aggregation_groups_conversation_count,
                    count,
                    count,
                )
                FolderType.PRESET_OFFICIALS -> pluralStringResource(
                    R.plurals.chat_aggregation_officials_conversation_count,
                    count,
                    count,
                )
                FolderType.SQL -> pluralStringResource(
                    R.plurals.chat_aggregation_sql_conversation_count,
                    count,
                    count,
                )
            }
            Text(desc)
        }
    }

    @Composable
    private fun FolderEditorDialog(
        title: String,
        folder: ChatFolder?,
        onDismiss: () -> Unit,
        onDelete: (suspend () -> Unit)? = null,
        onSavingChanged: (Boolean) -> Unit,
        onSave: suspend (ChatFolder) -> Unit
    ) {
        val scope = rememberCoroutineScope()
        var saving by remember { mutableStateOf(false) }
        var failed by remember { mutableStateOf(false) }
        fun submit(action: suspend () -> Unit) {
            saving = true
            onSavingChanged(true)
            failed = false
            scope.launch {
                try {
                    action()
                    showToast(localizedChatString(R.string.chat_aggregation_saved))
                } catch (error: Exception) {
                    if (error is kotlinx.coroutines.CancellationException) throw error
                    WeLogger.e(TAG, "Failed to save folder", error)
                    failed = true
                } finally {
                    saving = false
                    onSavingChanged(false)
                }
            }
        }
        val folderId = remember(folder) { folder?.id ?: newFolderId() }
        var name by remember(folder) { mutableStateOf(folder?.name ?: "") }
        var members by remember(folder) { mutableStateOf(folder?.members?.toSet().orEmpty()) }

        var type by remember(folder) { mutableStateOf(folder?.type ?: FolderType.MANUAL) }
        var selectFields by remember(folder) { mutableStateOf(folder?.selectFields ?: "r.username") }
        var whereClause by remember(folder) { mutableStateOf(folder?.whereClause ?: "") }

        val matchedCount = remember(type, members, selectFields, whereClause) {
            val tempFolder = ChatFolder(
                id = folderId,
                name = name,
                members = members.toList(),
                type = type,
                selectFields = selectFields,
                whereClause = whereClause
            )
            // Resolve directly instead of going through getFolderMembers: that cache is keyed
            // by folder id, and this preview folder reuses the id of the folder being edited,
            // so the cached (stale) member list would freeze the count at the first result.
            resolveFolderMembers(tempFolder).size
        }

        var hasAvatar by remember(folderId) {
            mutableStateOf(CustomLocalFriendAvatars.hasCustomAvatar(folderId))
        }

        AlertDialogContent(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(),
            title = {
                Column {
                    Text(title)
                    if (saving) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (failed) Text(stringResource(R.string.logs_save_failed), color = MaterialTheme.colorScheme.error)
                }
            },
            text = {
                DefaultColumn {
                    OutlinedTextField(
                        enabled = !saving,
                        value = name,
                        onValueChange = { name = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.chat_aggregation_folder_name)) },
                        singleLine = true
                    )

                    var typeExpanded by remember { mutableStateOf(false) }
                    Column {
                        Text(
                            stringResource(R.string.chat_aggregation_mode),
                            style = MaterialTheme.typography.labelSmall,
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !saving) { typeExpanded = true }
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = folderTypeLabel(type),
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                        DropdownMenu(
                            expanded = typeExpanded,
                            onDismissRequest = { typeExpanded = false }
                        ) {
                            DropdownMenuItem(
                                enabled = !saving,
                                text = { Text(stringResource(R.string.chat_aggregation_mode_manual)) },
                                onClick = {
                                    type = FolderType.MANUAL
                                    typeExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                enabled = !saving,
                                text = { Text(stringResource(R.string.chat_aggregation_mode_all_groups)) },
                                onClick = {
                                    type = FolderType.PRESET_GROUPS
                                    typeExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                enabled = !saving,
                                text = { Text(stringResource(R.string.chat_aggregation_mode_all_officials)) },
                                onClick = {
                                    type = FolderType.PRESET_OFFICIALS
                                    typeExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                enabled = !saving,
                                text = { Text(stringResource(R.string.chat_aggregation_mode_sql)) },
                                onClick = {
                                    type = FolderType.SQL
                                    typeExpanded = false
                                }
                            )
                        }
                    }

                    when (type) {
                        FolderType.MANUAL -> {
                            Text(
                                pluralStringResource(
                                    R.plurals.chat_aggregation_selected_count,
                                    matchedCount,
                                    matchedCount,
                                ),
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val context = LocalContext.current
                                val localizedContext = LocalWeKitLocalizedContext.current
                                Button(
                                    enabled = !saving,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        showComposeDialog(context) {
                                            ContactsSelector(
                                                title = localizedContext.getString(
                                                    R.string.chat_aggregation_choose_conversations,
                                                ),
                                                contacts = remember { WeDatabaseApi.getContacts() },
                                                initialSelectedWxIds = members,
                                                onDismiss = this.onDismiss,
                                                onConfirm = {
                                                    members = it
                                                    this.onDismiss()
                                                }
                                            )
                                        }
                                    }
                                ) {
                                    Text(stringResource(R.string.chat_aggregation_choose_conversations))
                                }

                                if (hasAvatar) {
                                    Button(enabled = !saving, onClick = {
                                        CustomLocalFriendAvatars.removeAvatar(folderId)
                                        hasAvatar = false
                                    }) {
                                        Text(stringResource(R.string.chat_aggregation_clear_avatar))
                                    }
                                }
                                Button(enabled = !saving, onClick = {
                                    if (!CustomLocalFriendAvatars.isEnabled) {
                                        showToast(
                                            localizedChatString(R.string.chat_aggregation_enable_custom_avatar),
                                        )
                                    }

                                    CustomLocalFriendAvatars.selectAvatarImage(HostInfo.application, folderId)
                                }) {
                                    Text(
                                        stringResource(
                                            if (hasAvatar) {
                                                R.string.chat_aggregation_change_avatar
                                            } else {
                                                R.string.chat_aggregation_set_avatar
                                            },
                                        ),
                                    )
                                }
                            }
                        }

                        FolderType.PRESET_GROUPS -> {
                            Text(
                                pluralStringResource(
                                    R.plurals.chat_aggregation_auto_groups_count,
                                    matchedCount,
                                    matchedCount,
                                ),
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (hasAvatar) {
                                    Button(enabled = !saving, onClick = {
                                        CustomLocalFriendAvatars.removeAvatar(folderId)
                                        hasAvatar = false
                                    }) {
                                        Text(stringResource(R.string.chat_aggregation_clear_avatar))
                                    }
                                }
                                Button(
                                    enabled = !saving,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        CustomLocalFriendAvatars.selectAvatarImage(HostInfo.application, folderId)
                                    }
                                ) {
                                    Text(
                                        stringResource(
                                            if (hasAvatar) R.string.chat_aggregation_change_avatar
                                            else R.string.chat_aggregation_set_avatar,
                                        ),
                                    )
                                }
                            }
                        }

                        FolderType.PRESET_OFFICIALS -> {
                            Text(
                                pluralStringResource(
                                    R.plurals.chat_aggregation_auto_officials_count,
                                    matchedCount,
                                    matchedCount,
                                ),
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (hasAvatar) {
                                    Button(enabled = !saving, onClick = {
                                        CustomLocalFriendAvatars.removeAvatar(folderId)
                                        hasAvatar = false
                                    }) {
                                        Text(stringResource(R.string.chat_aggregation_clear_avatar))
                                    }
                                }
                                Button(
                                    enabled = !saving,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        CustomLocalFriendAvatars.selectAvatarImage(HostInfo.application, folderId)
                                    }
                                ) {
                                    Text(
                                        stringResource(
                                            if (hasAvatar) R.string.chat_aggregation_change_avatar
                                            else R.string.chat_aggregation_set_avatar,
                                        ),
                                    )
                                }
                            }
                        }

                        FolderType.SQL -> {
                            OutlinedTextField(
                                enabled = !saving,
                                value = selectFields,
                                onValueChange = { selectFields = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text(stringResource(R.string.chat_aggregation_select_fields)) },
                                singleLine = true
                            )
                            OutlinedTextField(
                                enabled = !saving,
                                value = whereClause,
                                onValueChange = { whereClause = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text(stringResource(R.string.chat_aggregation_where_clause)) },
                                singleLine = false,
                                maxLines = 4
                            )
                            Text(
                                text = pluralStringResource(
                                    R.plurals.chat_aggregation_current_match_count,
                                    matchedCount,
                                    matchedCount,
                                ),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = stringResource(R.string.chat_aggregation_sql_help),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (hasAvatar) {
                                    Button(enabled = !saving, onClick = {
                                        CustomLocalFriendAvatars.removeAvatar(folderId)
                                        hasAvatar = false
                                    }) {
                                        Text(stringResource(R.string.chat_aggregation_clear_avatar))
                                    }
                                }
                                Button(
                                    enabled = !saving,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        CustomLocalFriendAvatars.selectAvatarImage(HostInfo.application, folderId)
                                    }
                                ) {
                                    Text(
                                        stringResource(
                                            if (hasAvatar) R.string.chat_aggregation_change_avatar
                                            else R.string.chat_aggregation_set_avatar,
                                        ),
                                    )
                                }
                            }
                        }
                    }
                }
            },
            dismissButton = {
                if (onDelete != null) {
                    TextButton(onClick = { submit { onDelete() } }, enabled = !saving) { Text(stringResource(R.string.action_delete)) }
                }
                TextButton(onDismiss, enabled = !saving) { Text(stringResource(R.string.dialog_cancel)) }
            },
            confirmButton = {
                Button(
                    enabled = !saving && name.isNotBlank(),
                    onClick = {
                        val next = ChatFolder(
                            id = folderId,
                            name = name.trim(),
                            members = members.toList().sorted(),
                            type = type,
                            selectFields = selectFields.trim(),
                            whereClause = whereClause.trim(),
                            // Carry the pin state forward — editing a folder must not reset its pin.
                            pinFlag = folder?.pinFlag ?: 0L
                        )
                        submit { onSave(next) }
                    }
                ) { Text(stringResource(R.string.dialog_confirm)) }
            }
        )
    }

    private fun resolveFolderMembers(folder: ChatFolder): List<String> {
        return when (folder.type) {
            FolderType.MANUAL -> folder.members
            FolderType.PRESET_GROUPS -> {
                runCatching {
                    val result = WeDatabaseApi.executeQuery(
                        "SELECT r.username FROM rcontact r WHERE r.username LIKE '%@chatroom'"
                    )
                    result.mapNotNull { it["username"]?.toString() }
                }.getOrElse {
                    WeLogger.e(TAG, "failed to query preset groups", it)
                    emptyList()
                }
            }

            FolderType.PRESET_OFFICIALS -> {
                runCatching {
                    val result = WeDatabaseApi.executeQuery(
                        "SELECT r.username FROM rcontact r WHERE r.username LIKE 'gh_%'"
                    )
                    result.mapNotNull { it["username"]?.toString() }
                }.getOrElse {
                    WeLogger.e(TAG, "failed to query preset officials", it)
                    emptyList()
                }
            }

            FolderType.SQL -> {
                runCatching {
                    val select = folder.selectFields.ifBlank { "r.username" }
                    val where = folder.whereClause.ifBlank { "1=1" }
                    val query =
                        "SELECT $select FROM rcontact r LEFT JOIN img_flag i ON r.username = i.username LEFT JOIN rconversation c ON r.username = c.username WHERE $where"
                    val result = WeDatabaseApi.executeQuery(query)
                    result.mapNotNull { row ->
                        val username = row["username"]?.toString()
                        if (username != null) return@mapNotNull username
                        row.values.firstOrNull()?.toString()
                    }
                }.getOrElse {
                    WeLogger.e(TAG, "failed to query custom sql for folder ${folder.id}", it)
                    emptyList()
                }
            }
        }
    }

    private fun getFolderMembers(folder: ChatFolder): List<String> {
        if (folder.type == FolderType.MANUAL) {
            return folder.members
        }
        val cached = folderMembersCache[folder.id]
        if (cached != null) return cached

        if (!WeDatabaseApi.isReady) {
            return emptyList()
        }
        val resolved = resolveFolderMembers(folder)
        if (resolved.isNotEmpty()) {
            folderMembersCache[folder.id] = resolved
        }
        return resolved
    }

    private fun getFallbackAvatarMember(folderId: String): String? {
        val folder = folderById(folderId) ?: return null
        val members = getFolderMembers(folder).filterNot(::isFolderId).distinct()
        if (members.isEmpty()) return null
        // Prefer the member whose conversation most recently saw activity: WeChat bumps
        // rconversation.conversationTime on every sent or received message, so the folder
        // borrows the avatar of the chat that last lit up rather than an arbitrary first
        // member. Falls back to the first member when none of them has any message yet.
        return latestActiveMember(members) ?: members.firstOrNull()
    }

    /** Member with the newest conversationTime (latest sent/received message), or null. */
    private fun latestActiveMember(members: List<String>): String? {
        if (members.isEmpty() || !WeDatabaseApi.isReady) return null
        return runCatching {
            // Suppress the container SQL fallback while querying aggregate members directly.
            withQueryRewriteSuppressed {
                val placeholders = members.joinToString(",") { "?" }
                val cursor = WeDatabaseApi.rawQuery(
                    """
                    SELECT ${ConversationTable.USERNAME}
                    FROM ${ConversationTable.NAME}
                    WHERE ${ConversationTable.USERNAME} IN ($placeholders) AND ${ConversationTable.CONVERSATION_TIME} > 0
                    ORDER BY ${ConversationTable.CONVERSATION_TIME} DESC
                    LIMIT 1
                    """.trimIndent(),
                    arrayOf(*members.toTypedArray())
                )
                cursor.use { c ->
                    if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null
                }
            }
        }.onFailure {
            WeLogger.w(TAG, "failed to resolve latest active member", it)
        }.getOrNull()
    }

    @Volatile
    private var foldersCache: List<ChatFolder>? = null

    private fun loadFolders(): List<ChatFolder> {
        foldersCache?.let { return it }
        return runBlocking(Dispatchers.IO) {
            JsonDataMigration.requireCompleted("chat", "folders")
            WeKitDatabase.instance.conversationCollectionDao().getFolders()
        }.also { foldersCache = it }
    }

    private fun invalidateFolders() {
        foldersCache = null
        folderMembersCache.clear()
    }

    private suspend fun upsertFolder(folder: ChatFolder) {
        try {
            WeKitDatabase.instance.conversationCollectionDao().putFolder(folder)
        } finally {
            invalidateFolders()
        }
        syncFoldersToDatabase()
    }

    private suspend fun deleteFolder(id: String) {
        try {
            WeKitDatabase.instance.conversationCollectionDao().removeFolder(id)
        } finally {
            invalidateFolders()
        }
        syncFoldersToDatabase()
    }

    private fun folderById(folderId: String): ChatFolder? {
        return loadFolders().firstOrNull { it.id == folderId }
    }

    private fun newFolderId(): String = "$FOLDER_PREFIX${System.currentTimeMillis()}"

    private fun isFolderId(value: String): Boolean = value.startsWith(FOLDER_PREFIX)


    private data class StoredFolderRow(
        val flag: Long,
        val attrFlag: Int,
        val summary: FolderSummary
    )

    private data class MemberSummaryRow(
        val digest: String,
        val digestUser: String,
        val isSend: Int,
        val status: Int,
        val conversationTime: Long,
        val content: String,
        val msgType: String,
        val chatMode: Int
    )

    private class SummaryAccumulator {
        var latest: MemberSummaryRow? = null
        var normalUnread: Int = 0
        var mutedUnread: Int = 0
    }

    private data class FolderSummary(
        val digest: String = "",
        val digestUser: String = "",
        val isSend: Int = 0,
        val status: Int = 0,
        val conversationTime: Long = System.currentTimeMillis(),
        val unreadCount: Int = 0,
        val unreadMuteCount: Int = 0,
        val content: String = "",
        val msgType: String = "",
        val chatMode: Int = 0
    ) {
        /**
         * The folder row needs a mute attrflag bit set for the homepage badge to render a
         * small dot (WeChat w3.b requires unReadCount==0 && unReadMuteCount>0 && attrflag has
         * a mute bit). We add the bit only when there's muted-but-no-normal unread, and clear
         * it otherwise so a stale dot never lingers.
         */
        val attrFlag: Int
            get() = if (unreadCount == 0 && unreadMuteCount > 0) ATTR_FLAG_MUTE_BIT else 0
    }

    private object ConversationTable {
        const val NAME = "rconversation"
        const val USERNAME = "username"
        const val PARENT_REF = "parentRef"
        const val DIGEST = "digest"
        const val DIGEST_USER = "digestUser"
        const val IS_SEND = "isSend"
        const val STATUS = "status"
        const val CONVERSATION_TIME = "conversationTime"
        const val FLAG = "flag"
        const val UNREAD_COUNT = "unReadCount"
        const val UNREAD_MUTE_COUNT = "unReadMuteCount"
        const val CONTENT = "content"
        const val MSG_TYPE = "msgType"
        const val CHAT_MODE = "chatmode"
        const val ATTR_FLAG = "attrflag"

        val REQUIRED_COLUMNS = setOf(
            USERNAME,
            PARENT_REF,
            DIGEST,
            DIGEST_USER,
            IS_SEND,
            STATUS,
            CONVERSATION_TIME,
            FLAG,
            UNREAD_COUNT,
            UNREAD_MUTE_COUNT,
            CONTENT,
            MSG_TYPE,
            CHAT_MODE,
            ATTR_FLAG
        )
    }

    private object ContactTable {
        const val NAME = "rcontact"
        const val USERNAME = "username"
        const val NICKNAME = "nickname"
        const val CON_REMARK = "conRemark"
        const val LV_BUFF = "lvbuff"
        const val TYPE = "type"
        const val VERIFY_FLAG = "verifyFlag"

        val REQUIRED_COLUMNS = setOf(
            USERNAME,
            NICKNAME,
            TYPE,
            CON_REMARK,
            LV_BUFF,
            VERIFY_FLAG
        )
    }

    private object WeChatIntentExtra {
        const val CONTACT_USER = "Contact_User"
        const val CONTACT_CHAT_ROOM_ID = "Contact_ChatRoomId"
        const val ROOM_NAME = "room_name"
        const val CHAT_USER = "Chat_User"

        val ALL = listOf(
            CONTACT_USER,
            CONTACT_CHAT_ROOM_ID,
            ROOM_NAME,
            CHAT_USER
        )
    }

    private object WeChatFolderPlaceholder {
        const val CONVERSATION_BOX = "conversationboxservice"
        const val MESSAGE_FOLD = "message_fold"
    }


    private fun android.database.Cursor.getStringOrEmpty(column: String): String {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getString(index) ?: "" else ""
    }

    private fun android.database.Cursor.getIntOrZero(column: String): Int {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getInt(index) else 0
    }

    private fun android.database.Cursor.getLongOrZero(column: String): Long {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getLong(index) else 0L
    }

}
